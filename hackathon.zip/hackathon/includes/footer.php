<footer >
<style type="text/css">
  .footer {
   position: fixed;
   left: 0;
   bottom: 15px;
   width: 100%;
   margin-left: 400px;
}	
</style>
<div class="footer">
<img src="gandhi-150.jpg"><img src="digi-awards.jpg"><img src="web-directory.jpg"><img src="made-in-india.jpg"><img src="digital-india-logo.jpg"><img src="india-gov-logo.jpg"><img src="niclogo.jpg"></div>
</footer>