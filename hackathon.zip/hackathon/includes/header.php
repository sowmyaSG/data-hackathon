<header style="background: #fee7ea;height:80px;">
  <img style="height:70px;margin-top: 0px;" src="includes/logo.png" align="left">
	<img style="height:70px;float:right;margin-top: 0px;"  src="includes/swachha.png">
  <br><h2 align="center" >GRIEVANCE PORTAL</h2>
        
</header>