<aside>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> 
<style>
  li.topmenu
  {
     padding-right: 20px;
     list-style-type: none;
     
    
  }
  li:hover
  {
    background-color: white;
  }
  #sidemenu
  {
    margin-left: 20px;
    margin-top: 50px;
    height: 400px;
    width:210px;
    background-color:#fee7ea;
    position:absolute;
  }
  .bt1,.bt2,.bt3,.bt
  {
    margin-left:20px;
    border-radius:24px;
     background-color: #fdced4;
     font-size: 20px;
     margin-top: 15px;

  }
  .bt1:hover, .btdrop1:hover, .bt2:hover, .btdrop2:hover, .bt3:hover, .btdrop3:hover,.bt:hover,.btdrop:hover
  {
    background-color:white;
  }
 .btdrop1, .btdrop2, .btdrop3
  {
    margin-left:30px;
    border-radius:24px;
     background-color: #fdced4;
     font-size: 20px;
    display:none;
    margin-top: 15px;
   width: 150px;
   font-size: 15px;
   
  }
 .bt > a,.btdrop2>a{
  color: black;
 }
img
{
  margin-top: 15px;
}
</style>
<script>
$(document).ready(function(){
  $(".bt2").click(function(){
    $(".btdrop2").slideToggle("slow");

  });
});
$(document).ready(function(){
  $(".bt3").click(function(){
    $(".btdrop3").slideToggle("slow");

  });
});
  </script>
<div id="sidemenu">
<button class="bt1">Dashboard</button>
<button class="bt2">Lodge Grievance</button>
   <button class="btdrop2"><a href="complaint.php">Public</a></button>
    <button class="btdrop2"><a href="">Pension</a></button>

<button class="bt"> <a href="complaint.php">Edit profile</a></button>
<button class="bt"><a href="account_activity.php"> Account Activity</a></button>
<button class="bt"><a href="complaint.php">View Status</a></button><br>
<button class="bt"><a href="logout.php">Log Out</a></button><br>

 </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>  
</aside>