<?php
session_start();
include('includes/config.php');
include('includes/header.php');
include('includes/sidebar1.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{
date_default_timezone_set('Asia/Kolkata');// change according timezone
$currentTime = date( 'd-m-Y h:i:s A', time () );
$id=$_SESSION['alogin'];
if(isset($_GET['uid']) && $_GET['action']=='del')
{
$userid=$_GET['uid'];
$query=mysqli_query($con,"delete from `register` where id='$userid'");
header('location:manage-users.php');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Admin| Manage Users</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
	<script language="javascript" type="text/javascript">
var popUpWin=0;
function popUpWindow(URLStr, left, top, width, height)
{
 if(popUpWin)
{
if(!popUpWin.closed) popUpWin.close();
}
popUpWin = open(URLStr,'popUpWin', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=yes,width='+600+',height='+600+',left='+left+', top='+top+',screenX='+left+',screenY='+top+'');
}

</script>
<style>
	.container {
  border-radius: 5px;
  //background-color: #f2f2f2;
  margin-left:200px;
  margin-top:40px;
  margin-bottom: 100px;
  overflow-y:scroll;
  overflow-x:hidden;
  position: fixed;
  width:75%;height: 70%;
 padding-left: 100px;
}

</style>
</head>
<body>
<div class="container">

	<h3>Manage User</h3>
							
								<table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped	 display" width="100%">
									<thead>
										<tr>
											<th>#</th>
											<th> Name</th>
											<th>Email </th>
											<th>Contact no</th>
											<th>Reg. Date </th>
											<th>Action</th>
										
										</tr>
									</thead>
									<tbody>

<?php $query=mysqli_query($con,"select * from `register` where `id` in(select `userId` from `tblcomplaints` where `maincat`=(SELECT `maincat` from `admin` where `id` ='$id') and `bank`=(SELECT `bank` from `admin` where `id` ='$id') and `branch`=(SELECT `branch` from `admin` where `id` ='$id'))");
$cnt=1;
while($row=mysqli_fetch_array($query))
{
?>									
										<tr>
											<td><?php echo htmlentities($cnt);?></td>
											<td><?php echo htmlentities($row['name']);?></td>
											<td><?php echo htmlentities($row['email']);?></td>
											<td> <?php echo htmlentities($row['contactNo']);?></td>
										
											<td><?php echo htmlentities($row['regDate']);?></td>

<td><a href="javascript:void(0);" onClick="popUpWindow('http://localhost/hackathon/officer/userprofile.php?uid=<?php echo htmlentities($row['id']);?>');" title="View Details">
<button type="button" class="btn btn-primary">View Detials</button>
											</a>
<a href="manage-users.php?uid=<?php echo htmlentities($row['id']);?>&&action=del" title="Delete" onClick="return confirm('Do you really want to delete ?')">
<button type="button" class="btn btn-danger">Delete</button></a>

										</td>
											
										<?php $cnt=$cnt+1; } ?>
										</tr>
									</tbody>
								</table>
							</div>
						

<?php include('includes/footer.php');?>
</body>
<?php } ?>