<?php
session_start();
include('include/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{
date_default_timezone_set('Asia/Kolkata');// change according timezone
$currentTime = date( 'd-m-Y h:i:s A', time () );


?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Admin| Report for Complaints</title>
</head>
<body>
	
	<div class="module-body table">
                              
                               
							
								<table cellpadding="1" cellspacing="1" border="1"  >
									
									<thead>
										<tr>
											<th>Complaint No</th>
											<th> complainant Name</th>
											<th>Reg Date</th>
											<th>Status</th>
											
										
											
										<!--SELECT `tblcomplaints`.*,users.fullName as name FROM `tblcomplaints` join users on users.id=tblcomplaints.userId where regDate in (select regDate from `tblcomplaints` where regDate>='$from%' and regDate<='$to%')-->
										</tr>
									</thead>
								
<tbody>
<?php
$to=$_GET['to'];
$from=$_GET['from'];
$query=mysqli_query($con,"SELECT `users`.fullName as name,`tblcomplaints`.* FROM `tblcomplaints`inner join `users` on `users`.id=`tblcomplaints`.userId  where `tblcomplaints`.regDate in (select `regDate` from `tblcomplaints` where `regDate`>='$from 00:00:00' and regDate<='$to 23:59:59')");
while($row=mysqli_fetch_array($query))
{
?>										
										<tr>
											<td><?php echo htmlentities($row['complaintNumber']);?></td>
											<td><?php echo htmlentities($row['name']);?></td>
											<td><?php echo htmlentities($row['regDate']);?></td>
										
											<td><?php echo htmlentities($row['status']);?></td>
											
										<!--	<td>   <a href="complaint-details.php?cid=<?php echo htmlentities($row['complaintNumber']);?>"> View Details</a> 
											</td>-->
											</tr>

										<?php  } ?>
										</tbody>
								</table>
								
							</div>

</body>
</html>
<?PHP } ?>