<?php
session_start();
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
  { 
header('location:index.php');
}
else
{
	if(isset($_POST['send']))
  {
    $complaintnumber=$_GET['cid'];
    $query=mysqli_query($con,"select * from complaintremark");
    $rw=mysqli_fetch_array($query);
   $status=$rw['status'];
   $remark=$rw['remark'];
   $query=mysqli_query($con,"select tblcomplaints.*,register.name as name from tblcomplaints join register on register.id=tblcomplaints.userId where tblcomplaints.complaintNumber='".$_GET['cid']."' and tblcomplaints.maincat='$maincat' and tblcomplaints.bank='$bank' and tblcomplaints.branch='$branch'");
$rw=mysqli_fetch_array($query);
$uname=$_SESSION['alogin'];
$mailid=mysqli_query($con,"select email from admin where id=$uname");
$reg=$rw['regDate'];
$ministry=$rw['ministry'];
$maincat=$rw['maincat'];
$subcat=$rw['subcat'];
$comdet=$rw['complaintDetails'];
$bank=$rw['bank'];
$branch=$rw['branch'];
  $content="Complaint Number:$complaintnumber
            Complainant Name:$nam
            Reg Date:$reg   
            Ministry:$ministry    
            Main Category:$maincat
            SubCategory:$subcat
            Bank:$bank
            Branch:$branch
            Complaint Details:$comdet
            Remarks:$remark
            File Status:$status
            ";
 $to=$_POST['mail2'];
 $sub="updates on complaints";

$header = "From:$mailid" . "\r\n" .
"CC: $mailid";
mail($to,$sub,$content,$header);
echo "<script>alert('Complaint details updated successfully');</script>";

  }
}?>
<script language="javascript" type="text/javascript">
function f2()
{
window.close();
}
function f3()
{
window.print(); 
}

</script>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>User Profile</title>
</head>
<body>

<div style="margin-left:50px;">
 <form name="updateticket" id="updatecomplaint" method="post"> 
<table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td  >&nbsp;</td>
      <td >&nbsp;</td>
    </tr>
    <tr height="50">
      <td><b>Complaint Number</b></td>
      <td><?php echo htmlentities($_GET['cid']); ?></td>
    </tr>
     <tr><td colspan="2">&nbsp;</td></tr>
    
    
    <tr>
      <td><b>Email</b></td>
      <td><input type="text" name="mail2"></td>
    </tr>
    <tr><td colspan="2">&nbsp;</td></tr>
    <tr><td></td><td><input type="submit" name="send" value="Send" onclick=""></td></tr>

   <tr><td colspan="2">&nbsp;</td></tr>

<tr>
  <td></td>
      <td >   
      <input name="Submit2" type="submit" class="txtbox4" value="Close this window " onClick="return f2();" style="cursor: pointer;"  /></td>
    </tr>
 
</table>
 </form>
</div>
</body>
</html>
