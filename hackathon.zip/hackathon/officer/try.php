<?php
  echo "From date should be less than to date " ;
 ?>