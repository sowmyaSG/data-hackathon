<?php
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/header.php');
include('includes/navigationbar.php');
include('includes/sidebar1.php');

if(strlen($_SESSION['login'])==0)
  { 
header('location:login.php');
}
else{
$r1=0;
$r2=0;
$r3=0;
$que=mysqli_query($con,"select * from `register` where `username`='".$_SESSION['login']."' or `email`='".$_SESSION['login']."' or `contactNo`='".$_SESSION['login']."'");


$que1=mysqli_query($con,"select * from `register` where `username`='".$_SESSION['login']."' or `email`='".$_SESSION['login']."' or `contactNo`='".$_SESSION['login']."'and id in (select `userId` from `tblcomplaints` where status is NULL )");

$que2=mysqli_query($con,"select * from `register` where `username`='".$_SESSION['login']."' or `email`='".$_SESSION['login']."' or `contactNo`='".$_SESSION['login']."'and id in (select `userId` from `tblcomplaints` where status ='in process' )");

$que3=mysqli_query($con,"select * from `register` where `username`='".$_SESSION['login']."' or `email`='".$_SESSION['login']."' or `contactNo`='".$_SESSION['login']."'and id in (select `userId` from `tblcomplaints` where status ='closed' )");
$r1=mysqli_num_rows($que1);
$r2=mysqli_num_rows($que2);
$r3=mysqli_num_rows($que3);
$r=mysqli_fetch_array($que);

  ?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
	<title>Dashboard</title>
	<style type="text/css">
		span.b {
               display: inline-block;
               width: 200px;
               height: 150px;
               padding: 5px;
               border: 2px solid black;    
               background-color:#bf80ff ; 
               border-radius: 50px 25px;
               }
        span.c {
               display: inline-block;
               width: 200px;
               height: 20px;
               padding: 20px;
               border: 2px solid black;    
               background-color:#bf80ff ; 
               border-radius: 50px 25px;
               }
         div.i
         {
           padding-top: -20px;
         }
         #myBar {
  width: 10%;
  height: 30px;
  background-color: ;
  text-align: center;
  line-height: 30px;
  color: black;
}
#myProgress 
{
  width: 10%;
  background-color:;
}

#myBar1 {
  width: 10%;
  height: 30px;
  background-color:;
  text-align: center;
  line-height: 30px;
  color: black;
}#myBar2 {
  width: 10%;
  height: 30px;
  background-color:;
  text-align: center;
  line-height: 30px;
  color: black;
}
#myBar3 {
  width: 10%;
  height: 30px;
  background-color:;
  text-align: center;
  line-height: 30px;
  color: black;
}


	</style>
</head>
<body >
   <div style="margin-top:-40px;float:right;margin-right:40px; ">WELCOME:<?php echo htmlentities($r['name']);?>


  <?php 
  $userphoto=$r['userImage'];
  if($userphoto==""):
?>
<img src="noimage.png" width="30" height="30" style="margin-top:1px;" >
<?php else:?>
  <img src="userimages/<?php echo htmlentities($userphoto);?>" style="margin-top:-10px;" width="30" height="30" >
 
<?php endif;?>

</div>
	
	<br/>
	<br/>
	<br/>
	<br/>
	<div align="center" class="i" style="margin-left: 55px;">
	<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2" style=" display: inline-block; ">
	  <span class="b"><img src="img/griev_total.png"><div id="myProgress">
  <div id="myBar" style="margin-left: 0px;margin-top: 0px;font-size:30px;"><?php echo htmlentities($r1);?></div>
</div>
</span>
	</div>
  

	<div class="col-lg-2 col-md-3 col-sm-2 col-xs-2" style="margin-top: -80px; display: inline-block;margin-left: 0px;">
	  <span class="b"><img src="img/griev_reg.png"><div id="myProgress">
  <div id="myBar1" style="margin-left: 0px;margin-top: 0px;font-size:30px;"><?php echo htmlentities($r2);?></div>
</div>
</span>
	</div>
	


	<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2" style=" display: inline-block;margin-left: 30px;">
	  <span class="b"><img src="img/griev_closed.png"><div id="myProgress">
  <div id="myBar2" style="margin-left: 0px;margin-top: 0px;font-size:30px;"><?php echo htmlentities($r3);?></div>
</div>
</span>
     </div>

<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2" style=" display: inline-block;margin-left: 30px;">
	  <span class="b"><img src="img/griev_total.png"><div id="myProgress">
  <div id="myBar3" style="margin-left: 0px;margin-top: 0px;font-size:30px;">0</div>
</div>
</span>
     </div>

    <br/>
    <br/>

   
    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2" style=" display: inline-block;">
    <span class="c"><b>NOT PROCESSED</b></span>
	</div>
    
    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2" style=" display: inline-block;margin-left: 20px;">
    <span class="c"><b>IN PROGRESS</b></span>
	</div>

    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2" style=" display: inline-block;margin-left: 30px;">
    <span class="c"><b>CLOSED</b></span>
	</div>

 <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2" style=" display: inline-block;margin-left: 30px;">
    <span class="c"><b>REPORT</b></span>
	</div>

	</div>

</body>
<?php include('footer.php');?>
</html>
<?php } ?>