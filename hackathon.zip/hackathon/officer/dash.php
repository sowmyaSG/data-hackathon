<!DOCTYPE html>
<html>
<head>
<style> 


.div1 {
  width: 150px;
  height: 100px;  
  margin-top:80px;
  margin-left: 300px;
  padding-top: 5px;
  position: absolute;
  left: 20px;
  border: 1px solid lightblue;
  border-radius:20px;
  text-align:center;
  background-color:lightblue;

}
.div2 {
  width: 150px;
  height: 18px;  
  margin-top:1px;
  padding-top:5px;
  
  border-radius:10px;
  text-align:center;
 margin-left:25px;
 position: absolute;
  background-color:lightblue;

 
 #myProgress 
{
  width: 10%;
  background-color:white;
}

#myBar {
  width: 10%;
  height: 30px;
  background-color: white;
  text-align: center;
  line-height: 30px;
  color: black;
}
#myProgress1 
{
  width: 10%;
  background-color:white;
}

#myBar1 {
  width: 10%;
  height: 30px;
  background-color: white;
  text-align: center;
  line-height: 30px;
  color: black;
}
#myProgress2
{
  width: 10%;
  background-color:white;
}

#myBar2 {
  width: 10%;
  height: 30px;
  background-color: white;
  text-align: center;
  line-height: 30px;
  color: black;
}

}
</style>
</head>
<body onload="move()">
<div >
<div class="div1" style="top: 150px;margin-left: 300px;"><div id="myProgress">
  <div id="myBar" style="margin-left: 80px;margin-top: 50px;font-size:30px;">10%</div>
</div>
</div>
<div class="div2" style="margin-left:310px;top: 360px;">NOT PROCESSED</div>


<div class="div1" style="margin-left:500px;top: 150px; "><div id="myProgress">
  <div id="myBar1" style="margin-left: 80px;margin-top: 50px;font-size:30px;">10%</div>
</div>
</div>
<div class="div2" style="margin-left:515px;top: 360px;">IN PROCESS</div>


<div class="div1" style="margin-left:700px;top: 150px; "><div id="myProgress">
  <div id="myBar2" style="margin-left: 80px;margin-top: 50px;font-size:30px;">10%</div>
</div>
</div>
<div class="div2" style="margin-left:715px;top: 360px;">CLOSED</div>

</div>
<script>
var i = 0;
function move() {
  if (i == 0) {
    i = 1;
    var elem = document.getElementById("myBar");
    var elem1 = document.getElementById("myBar1");
    var elem2 = document.getElementById("myBar2");
    
    var width = 1;
    var id = setInterval(frame, 50);
    function frame() {
      if (width >= 30) {
        clearInterval(id);
        i = 0;
      } else {
        width++;
        elem.style.width = width + "%";
        elem.innerHTML = width  + "%";
        elem1.style.width = width + "%";
        elem1.innerHTML = width  + "%";
      elem2.style.width = width + "%";
        elem2.innerHTML = width  + "%";
      
      }
    }
  }
}
</script>


</body>
</html>





