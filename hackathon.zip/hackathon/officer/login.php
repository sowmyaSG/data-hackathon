<?php include('includes/header.php');?>
<?php include('includes/sidebar.php');?>
<?php
session_start();
error_reporting(0);
include("includes/config.php");

if(isset($_POST['submit']))
{
 // echo $_POST['username'];
 // echo $_POST['password'];
$ret=mysqli_query($con,"SELECT * FROM `admin` WHERE `id`='".$_POST['username']."' or `email`='".$_POST['username']."' or `contactNo`='".$_POST['username']."' and `password`='".md5($_POST['password'])."'");
$num=mysqli_fetch_array($ret);
echo $num;
if($num>0)
{
$extra="notprocess-complaint.php";//
$_SESSION['alogin']=$_POST['username'];
$_SESSION['id']=$num['id'];
$host=$_SERVER['HTTP_HOST'];
$uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
header("location:http://$host$uri/$extra");
exit();
}
else
{
$_SESSION['errmsg']="Invalid username or password";
$extra="index.php";
$host  = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
header("location:http://$host$uri/$extra");
exit();
}
}



if(isset($_POST['change']))
{
   $email=$_POST['email'];
    $contact=$_POST['contact'];
    $password=md5($_POST['password']);
$query=mysqli_query($con,"SELECT * FROM `register` WHERE `email`='$email' and `contactNo`='$contact'");
$num=mysqli_fetch_array($query);
if($num>0)
{
mysqli_query($con,"update `register` set `password`='$password' WHERE `email`='$email' and `contactNo`='$contact' ");
$msg="Password Changed Successfully";

}
else
{
$errormsg="Invalid email id or Contact no";
}
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"> 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<style>
body
{
	margin: 0;
	padding:0;
	//font-family: Times New Roman;
	background:white;
}
.box
{
	width: 300px;
	margin-top:20px;
	height:450px;
	padding: 30px;
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-50%,-50%); ;
	//background-image: linear-gradient(#ebe6e0, white);
	text-align: center;
	background-color: #ebe6e0;
	
}
.box h2
{
	color: black;
	text-transform: uppercase;
	font-weight: 100;

}
.box input[type = "text"],.box input[type="password"]
{
	border: 0;
	//background:white;
	display: block;
	margin:15px auto;
	text-align: center;
	border:2px solid white;
	padding:14px 10px;
	width: 200px;
	outline: none;
	color: black;
	border-radius:12px ;
font-size:20px;
	//font-family:Times New Roman;

}
::placeholder {
  color:black;
  opacity: 1; /* Firefox */
  font-size:15px;
}

.box input[type = "text"],.box input[type="password"]
{
 width: 200px;
 height: 30px;

}
.box input[type = "submit"]
{
	border: 0;
	//background:white;
	display: block;
	//margin: 20px auto;
	text-align: center;
	border:2px solid white;
	//padding:14px 40px;
	//font-family: Times New Roman;
	outline: none;
	color: black;
	border-radius:12px ;
	margin-left: 150px;
	cursor: pointer;
	font-size:15px;
	width: 100px;
    height: 30px;

}
.box input[type = "submit"]:hover
{
	background:white;
}


</style>
<script type="text/javascript">
function valid()
{
 if(document.forgot.password.value!= document.forgot.confirmpassword.value)
{
alert("Password and Confirm Password Field do not match  !!");
document.forgot.confirmpassword.focus();
return false;
}
return true;
}




function userAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "check_availability.php",
data:'email='+$("#username").val(),
type: "POST",
success:function(data){
$("#user-availability-status1").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}
/*function callValidation()
{
//alert("hi");
 var string1 = removeSpaces(document.getElementById('mainCaptcha').value);
                      var string2 = removeSpaces(document.getElementById('txtInput').value);
                      if(string2.length==7 || ch==false){
                      if (string1 == string2 ){
                        document.getElementById("Captchastatus").setAttribute("style", "color:green"); 
                       document.getElementById("Captchastatus").innerText = "Success"; 
                       document.getElementById("Captchastatus1").value = "success"; 
                       ch=false;
                      }
                      else{        
                        document.getElementById("Captchastatus").setAttribute("style", "color:red"); 
                        document.getElementById("Captchastatus").innerText = "Wrong Captcha. Please Retype"; 
                        document.getElementById("Captchastatus1").value = "Wrong_Captcha"; 
                      }}
                    
var stat=document.getElementById('Captchastatus1').value;
//alert(stat);
status="success";
if(stat.localeCompare(status)==0)
{
$('#submit').removeAttr('disabled');
}
else

{
  document.getElementById("submit").setAttribute("disabled", "disabled"); 
}
}

function Captcha(){
                     var alpha = new Array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z');
                     var i;
                     for (i=0;i<6;i++){
                       var a = alpha[Math.floor(Math.random() * alpha.length)];
                       var b = alpha[Math.floor(Math.random() * alpha.length)];
                       var c = alpha[Math.floor(Math.random() * alpha.length)];
                       var d = alpha[Math.floor(Math.random() * alpha.length)];
                       var e = alpha[Math.floor(Math.random() * alpha.length)];
                       var f = alpha[Math.floor(Math.random() * alpha.length)];
                       var g = alpha[Math.floor(Math.random() * alpha.length)];
                      }
                    var code = a +' '+ b +' '+ c +' '+ d +' '+ e +' '+ f +' '+ g;
                    document.getElementById("mainCaptcha").value = code
                  }
                /*  function ValidCaptcha(){
                      var string1 = removeSpaces(document.getElementById('mainCaptcha').value);
                      var string2 = removeSpaces(document.getElementById('txtInput').value);
                      if (string1 == string2){
                       
                        document.getElementById("Captchastatus").innerText = "success"; 
                        //return true;
                      }
                      else{
                        document.getElementById("Captchastatus").innerText = "wrong Captcha";         
                        //return false;
                      }
                  }
                  function removeSpaces(string){
                    return string.split(' ').join('');
                  }*/











</script>
</head>
<body >
<form class="box" action="" method="post" >
	<h4>OFFICER LOG IN</h4><br>
	<span style="color:red;" ><?php echo htmlentities($_SESSION['errmsg']); ?><?php echo htmlentities($_SESSION['errmsg']="");?></span>
<input type="text" class="form-control" name="username" id="username" placeholder="Enter your ID" onchange="userAvailability()" required autofocus>
		            <span id="user-availability-status1" style="font-size:12px;"></span>		<br>      
		            <input type="password" class="form-control" name="password" id="password" class="password" required placeholder="Password" ><br>
              
                               <!--  <input class="form-control" style="width:150px;display: inline;background:#af9b83;font-size: 20px" type="text" id="mainCaptcha"  readonly/>
                 
              <input class="btn btn-theme btn-block" style="width:80px;display: inline; background:#af9b83;" type="button" id="refresh" value="Refresh" onclick="Captcha();" />
         
              <input class="form-control" style="width:120px;" placeholder="Enter Captcha" disabled="disabled" type="text" id="txtInput" required onkeyup="callValidation()" onblur="GenerateOTP();"> 

              <span id="Captchastatus" style="font-size:12px;"></span>
              <span id="captchastat" style="font-size:12px;"></span>
            <input type="hidden" class="form-control" name="Captchastatus1" id="Captchastatus1" value="">
                              <span id="otp-status" style="font-size:12px;"></span>
                <input type="hidden" class="form-control" name="otpstatus" id="otpstatus" value="">
              <input type="hidden" class="form-control" name="otp1" id="otp1" value="">-->
	
		            <label class="checkbox">
		                <span class="pull-right">
		                    <a data-toggle="modal" href="#myModal" > Forgot Password?</a>
		
		                </span>
		            </label>

		            <button disabled="disabled" class="btn btn-theme btn-block" style="background:#af9b83;color: black" name="submit" id="submit" type="submit">
                  <i class="fa fa-lock"></i> SIGN IN</button>
		          
		    
		              <!--  Don't have an account yet?<br/>
		                <a class="" href="registration.php">
		                    Create an account
		                </a>-->
		        </form>
		
		          <!-- Modal -->
		          <form  name="forgot" method="post">
		          <div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="myModal" class="modal fade">
		              <div class="modal-dialog">
		                  <div class="modal-content">
		                      <div class="modal-header">
		                      	<h4 class="modal-title">Forgot Password ?</h4>
		                          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
		                          
		                      </div>
		                      <div class="modal-body">
		                          <p>Enter your details below to reset your password.</p>
<input type="email" name="email" placeholder="Email" autocomplete="off" class="form-control" required><br >
<input type="text" name="contact" placeholder="contact No" autocomplete="off" class="form-control" required><br>
 <input type="password" class="form-control" placeholder="New Password" id="password" name="password"  required ><br />
<input type="password" class="form-control unicase-form-control text-input" placeholder="Confirm Password" id="confirmpassword" name="confirmpassword" required >

		
		                      </div>
		                      <div class="modal-footer">
		                          <button data-dismiss="modal" class="btn btn-default" type="button">Cancel</button>
		                          <button class="btn btn-theme" type="submit" name="change" onclick="return valid();">Submit</button>
		                      </div>
		                  </div>
		              </div>
		          </div>
		          <!-- modal -->
                </form>
<?php include('includes/footer.php');?>
</body>
</html>
