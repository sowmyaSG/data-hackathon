<?php
session_start();
include('includes/config.php');
include('includes/header.php');
include('includes/sidebar1.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{
date_default_timezone_set('Asia/Kolkata');// change according timezone
$currentTime = date( 'd-m-Y h:i:s A', time () );
$sql=mysqli_query($con,"select * from `admin` where id='".$_SESSION['alogin']."'");
$r=mysqli_fetch_array($sql);
$maincat=$r['maincat'];
$bank=$r['bank'];
$branch=$r['branch'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Admin| Not Process Yet Complaints</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
	<script language="javascript" type="text/javascript">
var popUpWin=0;
function popUpWindow(URLStr, left, top, width, height)
{
 if(popUpWin)
{
if(!popUpWin.closed) popUpWin.close();
}
popUpWin = open(URLStr,'popUpWin', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=yes,width='+500+',height='+600+',left='+left+', top='+top+',screenX='+left+',screenY='+top+'');
}

</script>
</head>
<body>

<div style="position: fixed;margin-left:260px;margin-top:40px;margin-bottom:100px;width:80%;overflow-y:scroll;
    overflow-x:hidden;height: 75%;">

							<h3>Complaint-Details</h3>
								<table cellpadding="0" cellspacing="0" border="0" class=" table table-bordered table-striped display" >
									
									
								
<tbody>
<?php 
$st='in process';
$query=mysqli_query($con,"select tblcomplaints.*,register.name as name from tblcomplaints join register on register.id=tblcomplaints.userId where tblcomplaints.complaintNumber='".$_GET['cid']."' and tblcomplaints.maincat='$maincat' and tblcomplaints.bank='$bank' and tblcomplaints.branch='$branch'");
$row=mysqli_num_rows($query);
if($row>0){
while($row=mysqli_fetch_array($query))
{
?>										
										<tr>
											<td><b>Complaint Number</b></td>
											<td><?php echo htmlentities($row['complaintNumber']);?></td>
											<td><b>Complainant Name</b></td>
											<td> <?php echo htmlentities($row['name']);?></td>
											<td><b>Reg Date</b></td>
											<td><?php echo htmlentities($row['regDate']);?>
											</td>
										</tr>

<tr>                                        
	                                        <td><b>Ministry</b></td>
											<td><?php echo htmlentities($row['ministry']);?>
											</td>
											<td><b>Main Category </b></td>
											<td><?php echo htmlentities($row['maincat']);?></td>
											<td><b>SubCategory</b></td>
											<td> <?php echo htmlentities($row['subcat']);?></td>
											
										</tr>
<tr>
											<td><b>Bank </b></td>
											<td><?php echo htmlentities($row['bank']);?></td>
											<td ><b>Branch</b></td>
											<td> <?php echo htmlentities($row['branch']);?></td>
											<td><b>Loan Number</b></td>
											<td><?php echo htmlentities($row['loannumber']);?></td>
											
										</tr>
<tr>
											<td><b>Complaint Details </b></td>
											
											<td colspan="5"> <?php echo htmlentities($row['description']);?></td>
											
										</tr>

											
<tr>
											<td><b>File(if any) </b></td>
											
											<td colspan="5"> <?php $cfile=$row['complaintFile'];
if($cfile=="" || $cfile=="NULL")
{
  echo "File NA";
}
else{?>
<a href="../public/complaintdocs/<?php echo htmlentities($row['complaintFile']);?>" target="_blank"> View File
</a>
<?php } ?></td>
</tr>

<tr>
<td><b>Final Status</b></td>
											
											<td colspan="5"><?php if($row['status']=="")
											{ echo "Not Process Yet";
} else {
										 echo htmlentities($row['status']);
										 }?></td>
											
										</tr>

<!--<?php $ret=mysqli_query($con,"select complaintremark.remark as remark,complaintremark.status as sstatus,complaintremark.remarkDate as rdate from complaintremark join tblcomplaints on tblcomplaints.complaintNumber=complaintremark.complaintNumber where complaintremark.complaintNumber='".$_GET['cid']."'");
while($rw=mysqli_fetch_array($ret))
{
?>
<tr>
<td><b>Remark</b></td>
<td colspan="5"><?php echo  htmlentities($rw['remark']); ?> <b>Remark Date :</b><?php echo  htmlentities($rw['rdate']); ?></td>
</tr>

<tr>
<td><b>Status</b></td>
<td colspan="5"><?php echo  htmlentities($rw['sstatus']); ?></td>
</tr>
<?php }?>-->





<tr>
											<td><b>Action</b></td>
											
											<td> 
											<?php if($row['status']=="closed"){

												} else {?>
<a href="javascript:void(0);" onClick="popUpWindow('http://localhost/hackathon/officer/updatecomplaint.php?cid=<?php echo htmlentities($row['complaintNumber']);?>');" title="Update order">
											 <button type="button" class="btn btn-primary">Take Action</button></a>
											<?php } ?></td><td>
											<a href="javascript:void(0);" onClick="popUpWindow('http://localhost/hackathon/officer/sendmail.php?cid=<?php echo htmlentities($row['complaintNumber']);?>');" title="Update order">
											 <button type="button" class="btn btn-primary">Send Mail</button></a></td>
											<td colspan="3"> 
											<a href="javascript:void(0);" onClick="popUpWindow('http://localhost/hackathon/officer/userprofile.php?uid=<?php echo htmlentities($row['userId']);?>&cid=<?php echo htmlentities($row['complaintNumber']);?>');" title="Update order">
											 <button type="button" class="btn btn-primary">View User Detials</button></a></td>
											 	
										

											
										</tr>
										<?php  } ?>
										<?php  } ?>
										</tbody>
								</table>
							</div>
								

						
						
					
<?php include('includes/footer.php');?>

</body></html>
<?php } ?>

