<aside>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> 
<style>
  li.topmenu
  {
     padding-right: 20px;
     list-style-type: none;
     
    
  }
  li:hover
  {
    background-color: white;
  }
  #sidemenu
  {
    margin-left: 20px;
    margin-top: 50px;
    height: 400px;
    width:210px;
    background-color:#fee7ea;
    position:absolute;
  }
  .bt1,.bt2,.bt3,.bt
  {
    margin-left:20px;
    border-radius:24px;
     background-color: #fdced4;
     font-size: 20px;
     width:140px;
     margin-top: 15px;

  }
  .bt1:hover, .btdrop1:hover, .bt2:hover, .btdrop2:hover, .bt3:hover, .btdrop3:hover,.bt:hover,.btdrop:hover
  {
    background-color:white;
  }
 .btdrop1, .btdrop2, .btdrop3
  {
    margin-left:50px;
    border-radius:24px;
     background-color: #fdced4;
     font-size: 20px;
    display:none;
    margin-top: 15px;
   width: 150px;
   font-size: 15px;
   
  }
button > a{
  color: black;
 }
img
{
  margin-top: 15px;
}
</style>
<script>
$(document).ready(function(){
  $(".bt1").click(function(){
    $(".btdrop1").slideToggle("slow");

  });
});
$(document).ready(function(){
  $(".bt2").click(function(){
    $(".btdrop2").slideToggle("slow");

  });
});
$(document).ready(function(){
  $(".bt3").click(function(){
    $(".btdrop3").slideToggle("slow");

  });
});
  </script>
<div id="sidemenu">
<img src="guide.png" style="height:25px;margin:7px"> <button class="bt1" style="width:140px;">Guidelines </button>
  <button class="btdrop1"><a href="">Redress of Public Grievance </a></button>
    <button class="btdrop1"><a href="">Other Guidelines</a></button>

<img src="redressal.png" style="height:40px;"> <button class="bt2" style="width:140px;">Redressal</button><br>
   <button class="btdrop2"><a href="">Mechanism</a></button>
    <button class="btdrop2"><a href="">Process Flow</a></button>
<img src="employee.jpg" style="height:30px;margin:7px"><button class="bt3" style="width:140px;"> Nodal Officer</button>
   <button class="btdrop3"><a href="">Central Government</a></button>
    <button class="btdrop3"><a href="">State Government</a></button>
<img src="contact.png" style="height:25px;margin:7px"><button class="bt">Contact Us</button><br>
<img src="about.png" style="height:25px;margin:7px"><button class="bt">About Us</button><br>

 </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>  
</aside>