<aside>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<style>
  li.topmenu
  {
     padding-right: 20px;
     list-style-type: none;
     
    
  }
  li:hover
  {
    background-color: white;
  }
  #sidemenu
  {
    margin-left: 20px;
    margin-top: 50px;
    height: 400px;
    width:230px;
    background-color: #fdced4;
    position:absolute;
  }
  .bt1,.bt2,.bt3,.bt
  {
    //margin-left:20px;
    border-radius:24px;
     background-color: #fdced4;
     font-size: 20px;
     margin-top: 15px;


  }
  .bt1:hover, .btdrop1:hover, .bt1:hover, .btdrop1:hover, .bt1:hover, .btdrop1:hover,.bt:hover,.btdrop:hover
  {
    background-color:white;
  }
 .btdrop1, .btdrop2, .btdrop3,.btdro
  {
    //margin-left:px;
    border-radius:24px;
     background-color: #fdced4;
     font-size: 20px;
    //display:none;
    margin-top: 10px;
   //width: 150px;
   font-size: 15px;
   
  }
 .btdrop1 > a{
  color: black;
 }
  .bt2 > a{
  color: black;
 }
 .btdro
 {
  display: none;
 }
img
{
  margin-top: 15px;
}
</style>
<script>
$(document).ready(function(){
  $(".bt1").click(function(){
    $(".btdro").slideToggle("slow"); 
  });
});

  </script>
<div id="sidemenu">
<i  style="margin: 10px;" class="fa fa-cog" aria-hidden="true"></i><button class="bt1" style="margin-top:5px;">Manage Complaints</button>
     <div class="btdro"><button class="btdrop1" style="margin-left:10px;"><i  class="fa  fa-tasks" aria-hidden="true"></i> <a href="notprocess-complaint.php"> Not Processed Complaint </a><?php
$rt = mysqli_query($con,"SELECT * FROM tblcomplaints where status is null");
$num1 = mysqli_num_rows($rt);
{?>
    
                      <b style="background-color:#ff0000;width: 3px;padding-left:1px;"><?php echo htmlentities($num1); ?></b>
                      <?php } ?> </button>


                   <button class="btdrop1" style="margin-left:10px;width:210px;"> <i  class="fa fa-spinner " aria-hidden="true"></i><a href="inprocess-complaint.php"> Inprocess Complaints</a> <?php 
  $status="in Process";                   
$rt = mysqli_query($con,"SELECT * FROM tblcomplaints where status='$status'");
$num1 = mysqli_num_rows($rt);
{?><b style="background-color:#ff5c33;width: 3px;padding-left:1px;"><?php echo htmlentities($num1); ?></b>
<?php } ?></button>
                      

                      <button class="btdrop1"style="margin-left:10px;width:210px;"> <i  class="fa fa-check " aria-hidden="true"></i><a href="closed-complaint.php"> Closed complaints</a>
 <?php  $status="closed";                   
$rt = mysqli_query($con,"SELECT * FROM tblcomplaints where status='$status'");
$num1 = mysqli_num_rows($rt);
{?><b style="background-color:#88cc00;width: 3px;padding-left:10px;text-align:center;"><?php echo htmlentities($num1); ?></b>
<?php } ?>
</button>

 <button class="btdrop1" style="margin-left:10px;width:210px;"> <i  class="fa fa-check " aria-hidden="true"></i><a href="report.php"> Report</a>
 <?php
$rt = mysqli_query($con,"SELECT * FROM tblcomplaints");
$num1 = mysqli_num_rows($rt);
{?>
    
                      <b style="background-color:#0080ff;width: 3px;padding-left:10px;text-align:center;"><?php echo htmlentities($num1); ?></b>
                      <?php } ?>
</button>
</div>
<i  style="margin: 10px;" class="fa fa-users" aria-hidden="true"></i><button class="bt2" style="margin-top:15px;width:180px;"><a href="manage-users.php">Manage Users</a></button><br>
 
<i  style="margin: 10px;" class="fa fa-sign-out" aria-hidden="true"></i><button class="bt2" style="margin-top:15px;width:180px;"><a href="logout.php">Logout</a></button>
 
 </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>  
</aside>