<?php session_start();
error_reporting(0);
include('includes/config.php');
include('includes/header.php');
include('includes/navigationbar.php');
include('includes/sidebar1.php');
if(strlen($_SESSION['login'])==0)
  { 
header('location:login.php');
}
else{
$que=mysqli_query($con,"select * from `register` where `username`='".$_SESSION['login']."' or `email`='".$_SESSION['login']."' or `contactNo`='".$_SESSION['login']."'");
$r=mysqli_fetch_array($que);
  $ret=mysqli_query($con,"SELECT email FROM `register` WHERE `username`='".$_SESSION['login']."' or `email`='".$_SESSION['login']."' or `contactNo`='".$_SESSION['login']."' ");
$num=mysqli_fetch_array($ret);
 $email=$num['email'];

if(isset($_POST['submit1']))
{
$rno=(int) $_POST['otp1'];
$urno= (int) $_POST['otp'];
if($rno==$urno){
$extra="login.php";
header("Location: http://localhost/hackathon/public/complaint.php"); 
exit();

}
else{
$errormsg ="Invalid OTP" .$rno."\r " .$urno;
//echo "<p>Invalid OTP</p>";
//header("location:loginsuccess2.php");
}
}

//resend OTP
if(isset($_POST['resend']))
{
$message="<p class='w3-text-green'>Sucessfully send OTP to your mail.</p>";
$rno=$_POST['otp1'];
$email1=$_SESSION['login'];
$to=$email1;
$subject = "OTP";
$txt = "OTP: ".$rno."";
$headers = "From:$email1" . "\r\n" .
"CC:$email1";
mail($to,$subject,$txt,$headers);
$message="<p class='w3-text-green w3-center'><b>Sucessfully resend OTP to your mail.</b></p>";
}
}
?>

<!DOCTYPE html>
<html lang="en">
  <head >
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>GRS | User Login</title>

    
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>  
       <style>
.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  margin-left:270px;
  margin-top:40px;
  margin-bottom: 100px;
  overflow-y:scroll;
  overflow-x:hidden;
  position: fixed;
  width:75%;height: 50%;
 //padding-left: 100px;
} 

</style>
<script type="text/javascript">
function GenerateOTP() {

$("#loaderIcon").show();
$("#otp").removeAttr('disabled');
jQuery.ajax({
url: "process.php",
data:'email='+'<?php echo $email;?>',
type: "POST",
success:function(data){
alert(data);
$("#loaderIcon").hide();
//x="Mail send to your registered Mail ID"
//alert(x); 
x1=data;
//alert(x1);
 //$("input:text#otp1").val(x1);
 //alert($("#opt1").val(x1));
document.getElementById("otp1").value = x1; 

//alert(document.getElementById("opt1").value);

//$("#regno-availability-status1").html("Mail send to your registered Mail ID");


},
error:function (){}
});
}
var ch=true;
function buttondisable()
{
  var otpss = $("#otp").val();
  alert(otpss);
  if(otpss.length==6 || ch==false)
  {
  $('#submit1').removeAttr('disabled');
  document.getElementById("submit").innerHTML = "RE-GENERATE OTP";
  document.getElementById("otp-status").innerHTML = " "
  ch=false;
}
  else
  {
    document.getElementById("submit1").setAttribute("disabled", "disabled");
    document.getElementById("otp-status").innerHTML = "Check the length of OTP"
    var ch=true;
  }
}



</script>
  </head>

  <body>
    <div style="margin-top:-40px;float:right;margin-right:40px; ">WELCOME:<?php echo htmlentities($r['name']);?>


  <?php 
  $userphoto=$r['userImage'];
  if($userphoto==""):
?>
<img src="noimage.png" width="30" height="30" style="margin-top:1px;" >
<?php else:?>
  <img src="userimages/<?php echo htmlentities($userphoto);?>" style="margin-top:-10px;" width="30" height="30" >
 
<?php endif;?>

</div>
    <div class="container">
     <img src="LoaderIcon.gif" id="loaderIcon" style="display:none;position: absolute;top:50%;left: 45%;vertical-align: center" />       
          <form  name="login" id="login" method="post"> 
            <input type="hidden" name="visited" value="" >
            <h2 >TWO-STEP VERIFICATION</h2> 
            <p style="padding-left:4%; padding-top:2%;color:red">
              <?php if($errormsg){
echo htmlentities($errormsg);
                }?></p>
                <p style="padding-left:4%; padding-top:2%;  color:green">
              <?php if($msg){
echo htmlentities($msg);
                }?></p>
   
                
               <!-- <input type="text" class="form-control" name="otp" id="otp" placeholder="Enter OTP received in your mail" required onkeyup="ValidateOTP()">-->
                <input type="text" disabled="disabled" class="form-control" name="otp" id="otp" placeholder="Enter OTP received in your mail" onkeyup="buttondisable()" style="margin-left: 300px;width:50%;text-align: center;">
                <span id="otp-status" style="font-size:12px;"></span>
                <input type="hidden" class="form-control" name="otpstatus" id="otpstatus" value="">
                <input type="hidden" class="form-control" name="otp1" id="otp1" value="">
                <br>


                  <!--     <div class="form-group">
                            <div class="g-recaptcha" data-sitekey="6LeBKsQUAAAAAPNT5HaF_XYarwqF_SbMqezIZGw9" data-callback="verifyRecaptchaCallback" data-expired-callback="expiredRecaptchaCallback"></div>
                            <input class="form-control d-none" data-recaptcha="true" required data-error="Please complete the Captcha">
                            <div class="help-block with-errors"></div>
                        </div>
               -->
               <button class="btn btn-theme btn-block" style="background:#af9b83;margin-left: 200px;width: 70%" name="submit" id="submit" type="button" onclick="GenerateOTP()"><i class="fa fa-lock"></i>GENERATE  OTP</button>
               <button disabled="disabled" class="btn btn-theme btn-block" style="background:#af9b83;margin-left: 200px;width: 70%" name="submit1" id="submit1" type="submit"><i class="fa fa-lock"></i>PROCEED TO LODGE COMPLAINTS</button>
              <!-- <button class="btn btn-theme btn-block" style="background: darkblue;" name="resend">Resend</button>-->
  
            
               </form>   </div>
  <?php  include('includes/footer.php'); ?>
  </body></html>

