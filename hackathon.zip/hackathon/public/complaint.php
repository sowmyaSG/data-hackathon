<?php
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/header.php');
include('includes/navigationbar.php');
include('includes/sidebar1.php');

if(strlen($_SESSION['login'])==0)
  { 
header('location:login.php');
}
else{
$que=mysqli_query($con,"select * from `register` where `username`='".$_SESSION['login']."' or `email`='".$_SESSION['login']."' or `contactNo`='".$_SESSION['login']."'");
$r=mysqli_fetch_array($que);
$date=date();
$ministry="Finance Ministry";
if(isset($_POST['submit']))
{
$uid=$_SESSION['id'];
$ministry="Finance Ministry";
$maincat=$_POST['maincat'];
$subcat=$_POST['subcat'];
$bank=$_POST['bank'];
$branch=$_POST['branch'];
$description=$_POST['complaindetails'];
$compfile=$_FILES["compfile"]["name"];
$_SESSION['msg']="Comlaint Registered!!";
$host=$_SERVER['HTTP_HOST'];


move_uploaded_file($_FILES["compfile"]["tmp_name"],"complaintdocs/".$_FILES["compfile"]["name"]);
$query=mysqli_query($con,"insert into tblcomplaints(userId,ministry,maincat,subcat,bank,branch,description,complaintFile,userip) values('$uid','$ministry','$maincat','$subcat','$bank','$branch','$decription','$compfile','$uip')");

// code for show complaint number
$sql=mysqli_query($con,"select complaintNumber from tblcomplaints  order by complaintNumber desc limit 1");
while($row=mysqli_fetch_array($sql))
{
 $cmpn=$row['complaintNumber'];
}
$complainno=$cmpn;
echo '<script> alert("Your complain has been successfully filled and your complaintno is  "+"'.$complainno.'")</script>';
}
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

input[type=submit] {
  background-color: white;
  color: black;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  margin-left: 800px;
}

input[type=submit]:hover {
  background-color: white;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  margin-left:270px;
  margin-top:40px;
  margin-bottom: 100px;
  overflow-y:scroll;
  overflow-x:hidden;
  position: fixed;
  width:75%;height: 60%;
 padding-left: 100px;
}
.asterisk_input::after {
content:" *"; 
color: #e32;
position: absolute; 
margin: 0px 0px 0px -0px; 
font-size: xx-large; 
padding: 0 10px 0 0; }

select,input[type=text],input[type=date],input[type=file]
{
  margin-left:60px;
  width:35%;
  height: 8%;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
label
{
  margin-top: 20px;
}
</style>
<script type="text/javascript">
  
  $("#country").change(function() {
  if ($(this).val() == "yes") {
    $('#otherFieldDiv').show();
    $('#otherField').attr('required', '');
    $('#otherField').attr('data-error', 'This field is required.');
  } else {
    $('#otherFieldDiv').hide();
    $('#otherField').removeAttr('required');
    $('#otherField').removeAttr('data-error');
  }
});
$("#country").trigger("change");
</script>
</head>
<body>
  <div style="margin-top:-40px;float:right;margin-right:40px; ">WELCOME:<?php echo htmlentities($r['name']);?>


  <?php 
  $userphoto=$r['userImage'];
  if($userphoto==""):
?>
<img src="noimage.png" width="30" height="30" style="margin-top:1px;" >
<?php else:?>
  <img src="userimages/<?php echo htmlentities($userphoto);?>" style="margin-top:-10px;" width="30" height="30" >
 
<?php endif;?>

</div>
<div class="container">
 <!-- <?php echo htmlentities($date) ;?>-->
   <?php if(isset($_POST['submit']))
{?>
                  <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                  <strong>Well done!<?php echo htmlentities($_SESSION['msg']);?><?php echo htmlentities($_SESSION['msg']="");?></strong> 
                  </div>
<?php } ?>
  <form method="post" >
  Ministry/Department <span style="color: red;font-size: 25px;">&#42;</span><b style="margin-left: 150px;">Financial Services(Insurance Division)</b><br>
<label for="country">Select Main Category<span style="color: red;font-size: 25px;">&#42;</span></label>
    <select id="country" name="maincat" value="Select Main Category">
      <option value="Educational Loan">Education Loan Related</option>
      <option value="Housing Loan">Housing Loan</option>
      </select>
    
<br>
<label for="country">Select Next Level Category<span style="color: red;font-size: 25px;">&#42;</span> </label>
    <select id="country" name="subcat" value="Select Main Category">
      <option value="Educational Loan">Educational Loan</option>
      <option value="Housing Loan">Housing Loan</option>
      </select>

<br>
 <label for="lname">Bank <span style="color: red;font-size: 25px;">&#42;</span> </label>
     <select id="bank" name="bank" value="Select Main Category">
       <option value="Educational Loan">State Bank oF India</option>
      <option value="Housing Loan">Indian Bank</option>
     </select><br>
      


 <label for="lname">Branch/ Name of Bank/Branch <span style="color: red;font-size: 25px;">&#42;</span> </label>
    <input  type="text" id="lname" name="branch" placeholder="Please Enter Branch/Name of Bank and Branch"><br>


 <label for="lname">Date of Application<span style="color: red;font-size: 25px;">&#42;</span> </label>
    <input  type="date" id="lname" name="lastname" placeholder="Enter Date.." value="<?php echo htmlentities($date)?>"><br>

Text of grievance(Remarks):Maximum of 500 characters are allowed in description:
<span style="color: red;font-size: 25px;">&#42;</span> <br>
    <textarea id="subject" name="subject" placeholder="Write something.." rows="10" cols="100" maxlength="500"></textarea><br>
<label for="compfile">Complaint Related Doc(if any)</label><input type="file" name="compfile" id="compfile" value="">
 <input  type="submit"  name="submit" value="SUBMIT">  </form>

</div>
<?php  include('includes/footer.php'); ?>
</body>
</html>
<?php } ?>