<?php
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/header.php');
include('includes/navigationbar.php');
include('includes/sidebar1.php');
if(strlen($_SESSION['login'])==0)
  { 
header('location:index.php');
}
else{
date_default_timezone_set('Asia/Kolkata');// change according timezone
$currentTime = date( 'd-m-Y h:i:s A', time () );


if(isset($_POST['submit']))
{
$imgfile=$_FILES["image"]["name"];

// get the image extension
$extension = substr($imgfile,strlen($imgfile)-4,strlen($imgfile));
// allowed extensions
$allowed_extensions = array(".jpg","jpeg",".png",".gif");

// Validation for allowed extensions .in_array() function searches an array for a specific value.
if(!in_array($extension,$allowed_extensions))
{
echo "<script>alert('Invalid format. Only jpg / jpeg/ png /gif format allowed');</script>";
}
else
{
//rename the image file
$imgnewfile=md5($imgfile).$extension;
// Code for move image into directory
move_uploaded_file($_FILES["image"]["tmp_name"],"userimages/".$imgnewfile);
// Query for insertion data into database
$query=mysqli_query($con,"update register set userImage='$imgnewfile' where email='".$_SESSION['login']."'");
if($query)
{
$successmsg="Profile photo Successfully !!";
}
else
{
$errormsg="Profile photo not updated !!";
}
}
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>  

  </head>
<style type="text/css">
  .container {
  border-radius: 5px;
  background-color: #f2f2f2;
  margin-left:270px;
  margin-top:40px;
  margin-bottom: 100px;
  overflow-y:scroll;
  overflow-x:hidden;
  position: fixed;
  width:75%;height:60%;
 padding-left: 100px;
}

</style>
  <body>
 <div style="margin-top:-40px;float:right;margin-right:40px; ">WELCOME:  <?php echo htmlentities($r['name']);?>


  <?php 
  $userphoto=$r['userImage'];
  if($userphoto==""):
?>
<img src="noimage.png" width="30" height="30" style="margin-top:1px;" >
<?php else:?>
  <img src="userimages/<?php echo htmlentities($userphoto);?>" width="100" height="100">
  <a href="update-image.php"style="margin-left: 600px;margin-top: -350px;" >Change Photo</a><br><br>
<?php endif;?>

</div>
<div class="container">
         

                      <?php if($successmsg)
                      {?>
                      <div class="alert alert-success alert-dismissable">
                       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                      <b>Well done!</b> <?php echo htmlentities($successmsg);?></div>
                      <?php }?>

   <?php if($errormsg)
                      {?>

                      <div class="alert alert-danger alert-dismissable">
 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                      <b>Oh snap!</b><?php echo htmlentities($errormsg);?></div>
                      <?php }?>
 <?php $query=mysqli_query($con,"select * from register where email='".$_SESSION['login']."'");
 while($row=mysqli_fetch_array($query)) 
 {
 ?>                     

  <h4><i class="fa fa-user"></i>&nbsp;&nbsp;<?php echo htmlentities($row['name']);?>'s Profile</h4>
    
                      <form  enctype="multipart/form-data"  method="post" name="profile" >








<label class="col-sm-2 col-sm-2 control-label">User Photo</label>
<div class="col-sm-4">
<?php $userphoto=$row['userImage'];
if($userphoto==""):
?>
<img src="noimage.png" width="256" height="256" >
<?php else:?>
	<img src="userimages/<?php echo htmlentities($userphoto);?>" width="256" height="256">

<?php endif;?>
</div>
<input type="file" name="image"  required />

<?php } ?>

                        
<button type="submit" name="submit" class="btn btn-primary">Submit</button>

                          </form>
                          </div>
                          
                          
    <?php include("includes/footer.php");?>
  

 
  </body>
</html>
<?php } ?>
