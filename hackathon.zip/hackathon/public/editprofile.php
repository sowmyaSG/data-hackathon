<?php
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/header.php');
include('includes/sidebar1.php');
if(strlen($_SESSION['login'])==0)
  { 
header('location:index.php');
}
else{
date_default_timezone_set('Asia/Kolkata');// change according timezone
$currentTime = date( 'd-m-Y h:i:s A', time () );


if(isset($_POST['submit']))
{

  $fullname=$_POST['fullname'];
  $gender=$_POST['gender'];
  $address=$_POST['address'];
  $country=$_POST['country'];
  $state=$_POST['state'];
  $district=$_POST['district'];
  $contactno=$_POST['contactNo'];
  $landline=$_POST['landline'];
  $email=$_POST['email'];
  $exservice=$_POST['exservice'];
$query=mysqli_query($con,"update register set gender='$gender',address='$address',country='$country',state='$state','district'='$district' where email='".$_SESSION['login']."' or username='".$_SESSION['login']."' or contactNo='".$_SESSION['login']."'");
if($query)
{
$successmsg="Profile Successfully !!";
}
else
{
$errormsg="Profile not updated !!";
}
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>CMS | User Change Password</title>

   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

    <style>
.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  margin-left:270px;
  margin-top:40px;
  margin-bottom: 100px;
  overflow-y:scroll;
  overflow-x:hidden;
  position: fixed;
  width:80%;height: 70%;
 //padding-left: 100px;
} 
select,input[type=text],input[type=date],input[type=file]
{
  margin-left:30px;
  width:35%;
  height: 8%;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  display: inline;
}
label
{
  color: rgb();
  text-align: center;
  //font-style: italic;
  font-size: 20px;
  margin-top: 20px;
}

</style>
  
  </head>

  <body>
 <div class="container">
    <form method="post">
      <?php $ret=mysqli_query($con,"SELECT * FROM `register` WHERE `username`='".$_SESSION['login']."' or `email`='".$_SESSION['login']."' or `contactNo`='".$_SESSION['login']."' ");
$num=mysqli_fetch_array($ret);?>
                <label><b>NAME<span style="color: red;font-size: 20px;">&#42;</span></b></label>               
                 <input type="text" style="margin-left: 60px;" class="form-control" name="fullname" id="name" required="required" autofocus onblur="enable();" value="<?php echo htmlentities($num['name']);?>" disabled="disable">
                <label style="margin-left: 70px;"><b>GENDER<span style="color: red;font-size: 20px;">&#42;</span></b></label>
                <input type="radio" name="gender" onblur="enable();" id="gender" value="male" style="font-size:5px;margin-left: 10px;"><B style="padding-left:5px; ">MALE </B>
                   <input type="radio" name="gender"  onblur="enable();"id="gender" value="female" style="font-size:5px;margin-left: 10px;" ><B style="padding-left:5px; ">FEMALE</B>
                     <input type="radio" name="gender" id="gender" onblur="enable();" value="transgender" style="font-size:5px;margin-left: 10px;"><B style="padding-left:5px; ">TRANSGENDER</B><br>

                    <label><b>ADDRESS<span style="color: red;font-size: 20px;">&#42;</span></b></label>    
                   <input type="text"  class="form-control" id="address" placeholder="Address" name="address" required="required" onblur="enable();" autofocus> 
                  <input type="text" id="address" class="form-control"style="margin-left: 70px;"placeholder="Sublocality" name="address" required="required" onblur="enable();" autofocus><br>
                   <input type="text" class="form-control"  id="address"style="margin-left: 130px;margin-top: 20px;" placeholder="Locality" name="address" required="required"  onblur="enable();"autofocus>


                    <label style="margin-left: 70px;" ><b>PINCODE</b></label>
                   <input type="text" id="address" class="form-control" style="margin-left:10px;"placeholder="Pincode" name="address" required="required" autofocus><br>

                    <label><b>COUNTRY<span style="color: red;font-size: 20px;">&#42;</span></b></label>    
                <input type="text" class="form-control"  style="margin-left:25px;" id="country" placeholder="country" name="country" required="required" autofocus onblur="enable();">

                 <label style="margin-left: 70px;" ><b>Are you an ex-service man?<span style="color: red;font-size: 20px;">&#42;</span></b></label>
                    <input type="radio"  onblur="enable();"  name="exservice"  id="exservice" value="yes" style="font-size:5px;margin-left: 10px;"><B style="padding-left:5px; ">Yes </B>
                   <input type="radio" onblur="enable();" name="exservice" value="no" id="exservice" style="font-size:5px;margin-left: 10px;" ><B style="padding-left:5px; ">No</B> 
                   <br>
                  <label><b>STATE<span style="color: red;font-size: 20px;">&#42;</span></b></label> 
                <input type="text" id="state" class="form-control" style="margin-left:60px;" placeholder="state" name="state" required="required" autofocus onblur="enable();"><br>

                      <label><b>DISTRICT<span style="color: red;font-size: 20px;">&#42;</span></b></label>  
                <input type="text" class="form-control" id="district" placeholder="district" name="district" required="required" autofocus onblur="enable();"><br>

                  <label><b>EMAIL ID<span style="color: red;font-size: 20px;">&#42;</span></b></label>  
                <input type="text" class="form-control" placeholder="emailid" id="email"name="email" required="required" autofocus onblur="enable();" value="<?php echo htmlentities($num['email']);?>" disabled="disable"><br>

                 <label><b>CONTACT<span style="color: red;font-size: 20px;">&#42;</span></b></label>  
                 <input type="text" class="form-control" style="margin-left:25px;" placeholder="contact no" name="contactNo" id="contactNo"required="required" autofocus onblur="con();enable();" value="<?php echo htmlentities($num['contactNo']);?>" disabled="disable">
                    <span id="contact" style="font-size:12px;"></span><br>

                  <label><b>LANDLINE:</b></label> 
                 <input type="text" class="form-control" style="margin-left:20px;"placeholder="landline" name="landline" required="required" autofocus><br>
                 
               
               
                
  

<?php $userphoto=$num['userImage'];
if($userphoto==""):
?>
<img src="noimage.png" width="100" height="100"style="margin-left: 600px;margin-top: -100px;" >
<a href="update-image.php"style="margin-left: 600px;margin-top: -250px;" >Change Photo</a>
<?php else:?>
	<img src="userimages/<?php echo htmlentities($userphoto);?>" width="100" height="100" style="margin-left: 600px;margin-top: -100px;">
	<a href="update-image.php"style="margin-left: 600px;margin-top: -250px;" >Change Photo</a><br><br>
<?php endif;?>
<br>
<button class="btn btn-theme btn-block" disabled="disable" style="background:#af9b83;margin-left: 400px;width:100px;"  type="submit" name="submit" id="submit"><i class="fa fa-user"></i> Register</button>
 </form></div>
 <?php include('includes/footer.php');?>

</body>
</html>                 
                          
          	
          	
		
    

<?php } ?>
