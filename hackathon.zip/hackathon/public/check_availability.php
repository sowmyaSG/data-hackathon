<?php 
require_once("includes/config.php");
if(!empty($_POST["email"])) {
	$email= $_POST["email"];
	
		$result =mysqli_query($con,"SELECT * FROM `register` WHERE `username`='$email' or `email`='$email' or `contactNo`='$email' ");
		$count=mysqli_num_rows($result);
if($count>0)
{
echo "<span style='color:green'> Registered  User !!.</span>";
 echo "<script>$('#password').prop('disabled',false);</script>";
//echo "<script>$('#otp').prop('disabled',false);</script>";
 echo "<script>$('#txtInput').prop('disabled',false);</script>";
// echo "<script>$('#submit').prop('disabled',false);</script>";
} else{
	
	echo "<span style='color:red'> Please use the Registered  Email or Username or Password !!.</span>";
 echo "<script>$('#password').prop('disabled',true);</script>";
 //echo "<script>$('#otp').prop('disabled',true);</script>";
 //echo "<script>$('#txtInput').prop('disabled',true);</script>";
 echo "<script>$('#submit').prop('disabled',true);</script>";

}
}


?>
