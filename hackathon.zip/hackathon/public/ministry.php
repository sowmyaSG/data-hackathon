<?php
session_start();
include('includes/config.php');
include('includes/header.php');
include('includes/navigationbar.php');
include('includes/sidebar1.php');
if(strlen($_SESSION['login'])==0)
  { 
header('location:login.php');
}
else{
  $que=mysqli_query($con,"select * from `register` where `username`='".$_SESSION['login']."' or `email`='".$_SESSION['login']."' or `contactNo`='".$_SESSION['login']."'");
$r=mysqli_fetch_array($que);
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<style> 


.div1 {
  width: 120px;
  height: 80px;  
  //margin-top:50px;
  margin-left: 300px;
  padding-top: 20px;
  position: absolute;
  left: 20px;
  border: 1px solid lightblue;
  border-radius:12px;
  text-align:center;
  background-color:#ebe6e0;
  font-size: 15px;

}
.vl {
  border-left: 3px solid black;
  height: 120px;
  margin-left:55px;
  position: absolute;
}
.div2 {
  //width: 60px;
  height: 50px;  
  margin-top:1px;
  padding-top:5px;
  //border: 1px solid  maroon;
  //border-radius:10px;
  text-align:center;
 margin-left:25px;
 position: absolute;
}
</style>
</head>
<body>
 <div style="margin-top:-40px;float:right;margin-right:40px; ">WELCOME:<?php echo htmlentities($r['name']);?>


  <?php 
  $userphoto=$r['userImage'];
  if($userphoto==""):
?>
<img src="noimage.png" width="30" height="30" style="margin-top:1px;" >
<?php else:?>
  <img src="userimages/<?php echo htmlentities($userphoto);?>" style="margin-top:-10px;" width="30" height="30" >
 
<?php endif;?>

</div><br><br>
<div class="div1" style="top: 150px;"><b>POSTS</b></div>
<div class="vl" style="margin-left:372px;top: 230px;"></div>
<div class="div2" style="margin-left:320px;top: 327px;"><img src="img/india_post1.png" /></div>

<div class="div1" style="top: 150px;margin-left:460px;width: 175px;"><b>TELECOMMUNICATIONS</b></div>
<div class="vl" style="margin-left:565px;top: 230px;"></div>
<div class="div2" style="margin-left:505px;top: 327px;"><img src="img/dot.png" /></div>

<div class="div1" style="top: 150px;margin-left:670px;"><b><a href="loginsuccess.php" style="color: black">BANKING</a></b></div>
<div class="vl" style="margin-left:750px;top: 230px;"></div>
<div class="div2" style="margin-left:695px;top: 327px;"><a href="loginsuccess.php"><img src="img/bank.png" /></a></div>


<div class="div1" style="top: 150px;margin-left:820px;"><b>INSURANCE</b></div>
<div class="vl" style="margin-left:900px;top: 230px;"></div>
<div class="div2" style="margin-left:845px;top: 327px;"><img src="img/insurance.png" /></div>


<div class="div1" style="top: 150px;margin-left:980px;"><b>OTHERS</b></div>
<div class="vl" style="margin-left:1060px;top: 230px;"></div>
<div class="div2" style="margin-left:1000px;top: 327px;"><img src="img/OTHERS.png" /></div>
<?php include('includes/footer.php'); ?>
</body>
</html>
<?php } ?>