<?php
include('includes/config.php');
include('includes/header.php');
include('includes/sidebar.php');
error_reporting(0);
if(isset($_POST['submit']))
{
	$fullname=$_POST['fullname'];
	$gender=$_POST['gender'];
	$address=$_POST['address'];
	$country=$_POST['country'];
	$state=$_POST['state'];
	$district=$_POST['district'];
	$contactno=$_POST['contactNo'];
	$landline=$_POST['landline'];
	$email=$_POST['email'];
	$exservice=$_POST['exservice'];
	$query=mysqli_query($con,"insert into `register`(`name`,`gender`,`address`,`country`,`state`,`district`,`contactNo`,`landline`,`email`,`exservice`) values('$fullname','$gender','$address','$country','$state','$district','$contactno','$landline','$email','$exservice')");
	$msg="Registration successfull.A verification link is sent to your mail to set username and password ";
	$sql=mysqli_query($con,"select `id` from `register` where `name`='$fullname' ");
	$row=mysqli_fetch_array($sql);
	$_SESSION["id"]=$row['id'];
$content="http://http://localhost/hackathon/public/confirm.php";
 $to=$email;
 $sub="verification link";

$header = "From:$email" . "\r\n" .
"CC: $email";
mail($to,$sub,$content,$header);

	
	
}
?>
<!--insert into register(name,gender,address,country,state,district,pincode,contactNo,landline,email,exservice) values('$fullname','$gender','$address','$country','$state','$district','$contactno','$landline','$email','exservice')"-->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <title>CMS | User Registration</title>
 
    	<script>
function regnoAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "authorize_register.php",
data:'regno='+$("#regno").val(),
type: "POST",
success:function(data){
$("#regno-availability-status1").html(data);
x = data;
//alert(x);
x1= x.split("%</span>")[1];
//alert(x1);
 document.getElementById("email").value = x1; 
$("#loaderIcon").hide();
},
error:function (){}
});

}
function con()
{
	var x = document.getElementById("contactNo").value;
	var z=x.toString().length;
    //alert(z);
    if(z < 10)
	{$.ajax({
	url:"try.php",
	type: "POST",
    success:function(data){
       $("#contact").html(data);
   },
   error:function (){}
    });}
   if(z==10)
	{$.ajax({
	url:"try1.php",
	type: "POST",
    success:function(data){
       $("#contact").html(data);
   },
   error:function (){}
});}
}
function enable()
{
   var name=document.getElementById("name").value;
   var gender=document.getElementById("gender").value;
   var address=document.getElementById("address").value;
   var country=document.getElementById("country").value;
   var state=document.getElementById("state").value;
    var district=document.getElementById("district").value;
     var exservice=document.getElementById("exservice").value;
    var email=document.getElementById("email").value;
     var contactno=document.getElementById("contactNo").value;
   if((name!="")&&(gender!=" ")&&(address!="")&&(country!="")&&(state!="")&&(district!="")&&(exservice!="")&&(email!="")&&(contactno!=""))

       { $('#submit').removeAttr('disabled');}
}
</script>
<style>
.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  margin-left:270px;
  margin-top:40px;
  margin-bottom: 100px;
  overflow-y:scroll;
  overflow-x:hidden;
  position: fixed;
  width:80%;height: 70%;
 //padding-left: 100px;
}	
select,input[type=text],input[type=date],input[type=file]
{
  margin-left:30px;
  width:35%;
  height: 8%;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  display: inline;
}
label
{
	color: rgb();
	text-align: center;
	//font-style: italic;
	font-size: 20px;
	margin-top: 20px;
}

</style>

  </head>

  <body>
	 <div class="container">
		        	<?php if($msg){?>
 <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                  <strong>Well done! <?php echo htmlentities($msg);?><?php echo htmlentities($_SESSION['msg']="");?></strong>
                  </div>


		        		<?php }?>


		        
		      
		         <!--<input type="text" class="form-control" placeholder="Full Name" name="fullname" required="required" autofocus>
		         <img src="LoaderIcon.gif" id="loaderIcon" style="display:none" />
		            <br>
		         <input type="text" class="form-control" placeholder="" name="regno" id="regno" required="required" onBlur="regnoAvailability()">
		         <span id="regno-availability-status1" style="font-size:12px;"></span>
		            <br>   
		            <input type="email" class="form-control" placeholder="Email ID" id="email" name="email" required="required" readonly>
		             <span id="user-availability-status1" style="font-size:12px;"></span>
		            <br>
		            <input type="password" class="form-control" placeholder="Password" required="required" name="password"><br >
		             <input type="text" class="form-control" maxlength="10" name="contactno" id="cn" placeholder="Contact no" required="required" onBlur="con()" autofocus>
		              <span id="contact" style="font-size:12px;"></span>
		            <br>-->
		            <form method="post">
		            <label><b>NAME<span style="color: red;font-size: 20px;">&#42;</span></b></label>		           
		             <input type="text" style="margin-left: 60px;" class="form-control" placeholder="Full Name" name="fullname" id="name" required="required" autofocus onblur="enable();">
		            <label style="margin-left: 70px;"><b>GENDER<span style="color: red;font-size: 20px;">&#42;</span></b></label>
		            <input type="radio" name="gender" onblur="enable();" id="gender" value="male" style="font-size:5px;margin-left: 10px;"><B style="padding-left:5px; ">MALE </B>
                   <input type="radio" name="gender"  onblur="enable();"id="gender" value="female" style="font-size:5px;margin-left: 10px;" ><B style="padding-left:5px; ">FEMALE</B>
                     <input type="radio" name="gender" id="gender" onblur="enable();" value="transgender" style="font-size:5px;margin-left: 10px;"><B style="padding-left:5px; ">TRANSGENDER</B><br>

                    <label><b>ADDRESS<span style="color: red;font-size: 20px;">&#42;</span></b></label>		 
                   <input type="text"  class="form-control" id="address" placeholder="Address" name="address" required="required" onblur="enable();" autofocus> 
                  <input type="text" id="address" class="form-control"style="margin-left: 70px;"placeholder="Sublocality" name="address" required="required" onblur="enable();" autofocus><br>
                   <input type="text" class="form-control"  id="address"style="margin-left: 130px;margin-top: 20px;" placeholder="Locality" name="address" required="required"  onblur="enable();"autofocus>


                    <label style="margin-left: 70px;" ><b>PINCODE</b></label>
                   <input type="text" id="address" class="form-control" style="margin-left:10px;"placeholder="Pincode" name="address" required="required" autofocus><br>

                    <label><b>COUNTRY<span style="color: red;font-size: 20px;">&#42;</span></b></label>		 
		            <input type="text" class="form-control"  style="margin-left:25px;" id="country" placeholder="country" name="country" required="required" autofocus onblur="enable();">

		             <label style="margin-left: 70px;" ><b>Are you an ex-service man?<span style="color: red;font-size: 20px;">&#42;</span></b></label>
                    <input type="radio"  onblur="enable();"  name="exservice"  id="exservice" value="yes" style="font-size:5px;margin-left: 10px;"><B style="padding-left:5px; ">Yes </B>
                   <input type="radio" onblur="enable();" name="exservice" value="no" id="exservice" style="font-size:5px;margin-left: 10px;" ><B style="padding-left:5px; ">No</B>	
                   <br>
		              <label><b>STATE<span style="color: red;font-size: 20px;">&#42;</span></b></label>	
		            <input type="text" id="state" class="form-control" style="margin-left:60px;" placeholder="state" name="state" required="required" autofocus onblur="enable();"><br>

                      <label><b>DISTRICT<span style="color: red;font-size: 20px;">&#42;</span></b></label>	
		            <input type="text" class="form-control" id="district" placeholder="district" name="district" required="required" autofocus onblur="enable();"><br>

		              <label><b>EMAIL ID<span style="color: red;font-size: 20px;">&#42;</span></b></label>	
		            <input type="text" class="form-control" placeholder="emailid" id="email"name="email" required="required" autofocus onblur="enable();"><br>

		             <label><b>CONTACT<span style="color: red;font-size: 20px;">&#42;</span></b></label>	
		             <input type="text" class="form-control" style="margin-left:25px;" placeholder="contact no" name="contactNo" id="contactNo"required="required" autofocus onblur="con();enable();">
		                <span id="contact" style="font-size:12px;"></span><br>

		              <label><b>LANDLINE:</b></label>	
		             <input type="text" class="form-control" style="margin-left:20px;"placeholder="landline" name="landline" required="required" autofocus><br>
		             
		           <button class="btn btn-theme btn-block"  style="background:#af9b83;margin-left: 900px;width:100px;"  type="submit" name="submit" id="submit" ><i class="fa fa-user"></i> Register</button>
		           
		             </form></div>
  </body>
</html>
