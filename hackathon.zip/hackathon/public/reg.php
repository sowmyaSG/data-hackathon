<?php include('includes/header.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="style.css">
 </head>
<body >

  <br/>
  <h1><center>PUBLIC ACCOUNT REGISTRATION</center></h1><br/>
  <br/>
  <br/>
  <form action="#">
   
    
    <div class="split right">
    <div class="centered">

      <label><b>NAME:</b></label><br/>
      <input type="text"  id="name"  name="name" size="70">
    
    <br/>
    <br/>

    <label><b>GENDER :</b></label><br/>
      <br/>
      <input type="radio" name="gender" id="ma">
      <span id="ma"><b>MALE</b></span>
      <input type="radio" name="gender" id="ma">
      <span id="ma"><b>FEMALE</b></span><br/>
    
       <br/>
       <br/> 

      <label ><b>ADDRESS:</b></label><br/>
      <input type="text"  id="address"  name="address" size="70">
    
    <br/>
    <br/>
    
      <label><b>COUNTRY:</b></label><br/>
      <input type="text"  id="country"  name="country" size="70">
    
    <br/>
    <br/>

      <label ><b>STATE:</b></label><br/>
      <input type="text"  id="state"  name="state" size="70">
    
    <br/>
    <br/>

    <label ><b>DISTRICT:</b></label><br/>
      <input type="text"  id="district"  name="district" size="70">
    
    <br/>
    <br/>
     </div>
   </div>

   <div class="split left">
   <div class="centered">

     
     
      <label ><b>PINCODE:</b></label><br/>
      <input type="text"  id="pin"  name="pin" size="70">
    
    <br/>
    <br/>
     
      <label ><b>MOBILE NUMBER:</b></label><br/>
      <input type="text"  id="mobileno"  name="mobileno" size="70">
    
    <br/>
    <br/>
     
      <label ><b>EMAIL ID:</b></label><br/>
      <input type="email"  id="email"  name="email" size="70" >
    
    <br/>
    <br/>
    
    <label><b>ARE YOU AN EX-SERVICE MAN :</b></label><br/>
      <br/>
      <input type="radio" name="yes" id="ma">
      <span id="ma"><b>YES</b></span>
      <input type="radio" name="no" id="ma">
      <span id="ma"><b>NO</b></span>
       <br/>
    <br/>

      <label ><b>ENTER THE CAPTCHA:</b></label><br/>
      <input type="text" id="captcha"  name="captcha" size="70" >
    
   
      <br/>
      <br/>
      <br/>
     
    
    <button type="submit" id="sub">Submit</button>
  </div>
</div>

  </form>


</body>
</html>
