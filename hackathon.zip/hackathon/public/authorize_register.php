<?php 
require_once("includes/config.php");
if(!empty($_POST["username"])) {
	$regno= $_POST["username"];
	
		$result =mysqli_query($con,"select `username` from `register` where `username`='$regno' ");
		$count=0;
		$count=mysqli_num_rows($result);
		//$result2 =mysqli_query($con,"SELECT registerno,mailid FROM authorized_student WHERE registerno='$regno'");
		//$row = mysqli_fetch_row($result2);
        //$count1=0;
		//$result1 =mysqli_query($con,"SELECT registerno FROM users WHERE registerno='$regno'");
		//if($result1!=False)
		  //$count1=mysqli_num_rows($result1);
    
if($count!=0)
{
echo "<span style='color:green'> username already taken</span>";
 echo "<script>$('#submit').prop('disabled',false);</script>";
 echo "<span style='color:white'></span>";
 //echo "<font color='white'>".$row[1]."</font>";
}
}
?>
