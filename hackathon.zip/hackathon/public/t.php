<?php include('includes/header.php');?>
<?php include('includes/sidebar.php');?>
<html>
<head>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
 .box1 {
  width: 150px;
  height: 50px;
  border: 5px solid gray;
  
  border: 1px solid lightblue;
  border-radius:12px;
  text-align:center;
  background-color:#ebe6e0;
  font-size: 15px;
} 
 </style>
	</head>
<body>
<a href="officer/login.php"><img src="employee.jpg" style="margin-left: 400px;margin-top: 100px;" ></a>
<a href="public/login.php"><img src="user.png" style="margin-left: 200px;margin-top: 100px" ><br></a>
<div class="box1" style=" margin-left: 450px;  margin-top: 30px;"><a href="officer/login.php">OFFICER LOGIN</a></div>
<div class="box1" style=" margin-left: 880px;margin-top:-40px;"><a href="public/login.php">PUBLIC LOGIN</a></div>
<?php include('includes/footer.php');?>
</body>
</html>