<?php
session_start();
error_reporting(0);
include("includes/config.php");
include("includes/header.php");

if(isset($_POST['submit']))
{
 // echo $_POST['username'];
 // echo $_POST['password'];
$ret=mysqli_query($con,"SELECT * FROM `register` WHERE `username`='".$_POST['username']."' or `email`='".$_POST['username']."' or `contactNo`='".$_POST['username']."' and `password`='".md5($_POST['password'])."'");
$num=mysqli_fetch_array($ret);
echo $num;
if($num>0)
{
$extra="dashboard1.php";
//$extra="dashboard.php";//
//$_SESSION['otp1']=$_POST['otp1'];
$_SESSION['login']=$_POST['username'];
$_SESSION['id']=$num['id'];
$host=$_SERVER['HTTP_HOST'];
$uip=$_SERVER['REMOTE_ADDR'];
$status=1;
$log=mysqli_query($con,"insert into userlog(uid,username,userip,status) values('".$_SESSION['id']."','".$_SESSION['login']."','$uip','$status')");
$uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
header("location:http://$host$uri/$extra");
exit();
}
else
{
$_SESSION['login']=$_POST['username'];	
$uip=$_SERVER['REMOTE_ADDR'];
$status=0;
mysqli_query($con,"insert into userlog(username,userip,status) values('".$_SESSION['login']."','$uip','$status')");
$errormsg="Invalid username or password";
$extra="login.php";

}
}



if(isset($_POST['change']))
{
   $email=$_POST['email'];
    $contact=$_POST['contact'];
    $password=md5($_POST['password']);
$query=mysqli_query($con,"SELECT * FROM `register` WHERE `email`='$email' and `contactNo`='$contact'");
$num=mysqli_fetch_array($query);
if($num>0)
{
mysqli_query($con,"update `register` set `password`='$password' WHERE `email`='$email' and `contactNo`='$contact' ");
$msg="Password Changed Successfully";

}
else
{
$errormsg="Invalid email id or Contact no";
}
}
?>

<!DOCTYPE html>
<html lang="en" onunload="GenerateOTP();">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>GRS | User Login</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
        
    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">
    <style>
        <?php
   include("includes/sidebar.php");
   ?>
    </style>
<script type="text/javascript">
function valid()
{
 if(document.forgot.password.value!= document.forgot.confirmpassword.value)
{
alert("Password and Confirm Password Field do not match  !!");
document.forgot.confirmpassword.focus();
return false;
}
return true;
}




function userAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "check_availability.php",
data:'email='+$("#username").val(),
type: "POST",
success:function(data){
$("#user-availability-status1").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}
var ch=true;
function callValidation()
{
//alert("hi");
 var string1 = removeSpaces(document.getElementById('mainCaptcha').value);
                      var string2 = removeSpaces(document.getElementById('txtInput').value);
                      if(string2.length==7 || ch==false){
                      if (string1 == string2 ){
                        document.getElementById("Captchastatus").setAttribute("style", "color:green"); 
                       document.getElementById("Captchastatus").innerText = "Success"; 
                       document.getElementById("Captchastatus1").value = "success"; 
                       ch=false;
                      }
                      else{        
                        document.getElementById("Captchastatus").setAttribute("style", "color:red"); 
                        document.getElementById("Captchastatus").innerText = "Wrong Captcha. Please Retype"; 
                        document.getElementById("Captchastatus1").value = "Wrong_Captcha"; 
                      }}
                    
var stat=document.getElementById('Captchastatus1').value;
//alert(stat);
status="success";
if(stat.localeCompare(status)==0)
{
$('#submit').removeAttr('disabled');
}
else

{
  document.getElementById("submit").setAttribute("disabled", "disabled"); 
}
}

function Captcha(){
                     var alpha = new Array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z');
                     var i;
                     for (i=0;i<6;i++){
                       var a = alpha[Math.floor(Math.random() * alpha.length)];
                       var b = alpha[Math.floor(Math.random() * alpha.length)];
                       var c = alpha[Math.floor(Math.random() * alpha.length)];
                       var d = alpha[Math.floor(Math.random() * alpha.length)];
                       var e = alpha[Math.floor(Math.random() * alpha.length)];
                       var f = alpha[Math.floor(Math.random() * alpha.length)];
                       var g = alpha[Math.floor(Math.random() * alpha.length)];
                      }
                    var code = a + ' ' + b + ' ' + ' ' + c + ' ' + d + ' ' + e + ' '+ f + ' ' + g;
                    document.getElementById("mainCaptcha").value = code
                  }
                /*  function ValidCaptcha(){
                      var string1 = removeSpaces(document.getElementById('mainCaptcha').value);
                      var string2 = removeSpaces(document.getElementById('txtInput').value);
                      if (string1 == string2){
                       
                        document.getElementById("Captchastatus").innerText = "success"; 
                        //return true;
                      }
                      else{
                        document.getElementById("Captchastatus").innerText = "wrong Captcha";         
                        //return false;
                      }
                  }*/
                  function removeSpaces(string){
                    return string.split(' ').join('');
                  }











</script>
  </head>

  <body onload="Captcha();">

      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
     <img src="LoaderIcon.gif" id="loaderIcon" style="display:none;position: absolute;top:50%;left: 45%;vertical-align: center" />
	  <div style="background: white;" id="login-page">
	  	<div class="container">
	  		<img style="height:55px; margin-left: -5vw; width:100px;" src="ssnlogo.png" align="left">
	  		<h3 align="center" style="color:darkblue; font-weight: bold;">Grievance Redressal System</h3>
	<hr />
		      <form class="form-login" name="login" id="login" method="post">
		        <h2 style="background: darkblue;" class="form-login-heading">sign in now</h2>
		        <p style="padding-left:4%; padding-top:2%;  color:red">
		        	<?php if($errormsg){
echo htmlentities($errormsg);
		        		}?></p>

		        		<p style="padding-left:4%; padding-top:2%;  color:green">
		        	<?php if($msg){
echo htmlentities($msg);
		        		}?></p>
		        <div class="login-wrap">
		            <input type="text" class="form-control" name="username" id="username" placeholder="Enter your registered Mail-ID" onchange="userAvailability()" required autofocus>
		            <span id="user-availability-status1" style="font-size:12px;"></span>
		            <br>
		            <input type="password" class="form-control" name="password" id="password" class="password" required placeholder="Password" >
                <br>
                                 <input class="form-control" style="width:120px;display: inline;" type="text" id="mainCaptcha"  readonly/>
                 
              <input class="btn btn-theme btn-block" style="width:80px;display: inline; background: darkblue" type="button" id="refresh" value="Refresh" onclick="Captcha();" />
              <br>
              <br>
              <input class="form-control" style="width:120px;" placeholder="Enter Captcha" disabled="disabled" type="text" id="txtInput" required onkeyup="callValidation()" onblur="
              GenerateOTP();"> 

              <span id="Captchastatus" style="font-size:12px;"></span>
              <span id="captchastat" style="font-size:12px;"></span>
            <input type="hidden" class="form-control" name="Captchastatus1" id="Captchastatus1" value="">
                              <span id="otp-status" style="font-size:12px;"></span>
                <input type="hidden" class="form-control" name="otpstatus" id="otpstatus" value="">
              <input type="hidden" class="form-control" name="otp1" id="otp1" value="">
	
		            <label class="checkbox">
		                <span class="pull-right">
		                    <a data-toggle="modal" href="login.html#myModal"> Forgot Password?</a>
		
		                </span>
		            </label>

		            <button disabled="disabled" class="btn btn-theme btn-block" style="background: darkblue;" name="submit" id="submit" type="submit">
                  <i class="fa fa-lock"></i> SIGN IN</button>
	
		            <hr>
		           </form>
		            <div class="registration">
		                Don't have an account yet?<br/>
		                <a class="" href="registration.php">
		                    Create an account
		                </a>
		            </div>
		
		        </div>
		
		          <!-- Modal -->
		           <form class="form-login" name="forgot" method="post">
		          <div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="myModal" class="modal fade">
		              <div class="modal-dialog">
		                  <div class="modal-content">
		                      <div class="modal-header">
		                          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
		                          <h4 class="modal-title">Forgot Password ?</h4>
		                      </div>
		                      <div class="modal-body">
		                          <p>Enter your details below to reset your password.</p>
<input type="email" name="email" placeholder="Email" autocomplete="off" class="form-control" required><br >
<input type="text" name="contact" placeholder="contact No" autocomplete="off" class="form-control" required><br>
 <input type="password" class="form-control" placeholder="New Password" id="password" name="password"  required ><br />
<input type="password" class="form-control unicase-form-control text-input" placeholder="Confirm Password" id="confirmpassword" name="confirmpassword" required >

		
		                      </div>
		                      <div class="modal-footer">
		                          <button data-dismiss="modal" class="btn btn-default" type="button">Cancel</button>
		                          <button class="btn btn-theme" type="submit" name="change" onclick="return valid();">Submit</button>
		                      </div>
		                  </div>
		              </div>
		          </div>
		          <!-- modal -->
		          </form>
		
		      	  	
	  	
	  	</div>
	  </div>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.js"></script>
    
    <script src="assets/js/bootstrap.min.js"></script>
    <!--<script src='https://www.google.com/recaptcha/api.js'></script>-->

    <!--BACKSTRETCH-->
    <!-- You can use an image of whatever size. This script will stretch to fit in any screen size.-->
    <script type="text/javascript" src="assets/js/jquery.backstretch.min.js"></script>
    <script>
        $.backstretch("assets/img/login-bg.jpg", {speed: 500});
    </script>

 


  </body>
</html>
