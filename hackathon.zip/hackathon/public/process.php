 <?php
//session_start();
$rndno=rand(100000, 999999);//OTP generate
$message = urlencode("otp number.".$rndno);
$to=$_POST['email'];

$subject = "OTP";
$txt = "OTP: ".$rndno."";
//echo $to;
//echo $subject;
$headers = "From: sasirekhainfo@gmail.com" . "\r\n" .
"CC: ssasirekha@gmail.com";
//echo $headers;
mail($to,$subject,$txt,$headers);
echo $rndno;
 ?> 