 <?php
session_start();

$rno=$_POST['otp1'];
$urno=$_POST['otp'];
//echo $rno;
//echo $urno;
if(!strcmp($rno,$urno))
{
//$name=$_SESSION['name'];
$email=$_POST['email'];
//$phone=$_SESSION['phone'];
//For admin if he want to know who is register
$to="sasirekhainfo@gmail.com";
$subject = "Thank you!";
$txt = "Stakeholder Login from Email id: " .$email;
$headers = "From: sasirekhainfo@gmail.com" . "\r\n" .
"CC: ssasirekha@gmail.com";
mail($to,$subject,$txt,$headers);
//echo "<p>Thank you for show our Demo.</p>";
//For admin if he want to know who is register
echo "<span style='color:green'> Valid OTP </span>";
echo "<script>$('#submit').prop('disabled',false);</script>";
echo "<script>$('#txtInput').prop('disabled',false);</script>";
}
else{
	
//echo "%Invalid OTP";
echo "<script>$('#submit').prop('disabled',true);</script>";
echo "<script>$('#txtInput').prop('disabled',true);</script>";
echo "<span style='color:white'>%</span>";
echo "<span style='color:red'> Invalid OTP. Re-enter and Press Enter </span>";
}


