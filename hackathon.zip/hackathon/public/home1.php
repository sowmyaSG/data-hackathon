<aside>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> 
<style>
  li.topmenu
  {
     padding-right: 20px;
     list-style-type: none;
     
    
  }


  .main{
    top: 210px;
    left: 300px;
    position: absolute;
  }

  li:hover
  {
    background-color: white;
  }
  #sidemenu
  {
    margin-left: 20px;
    margin-top: 50px;
    height: 400px;
    width:210px;
    background-color: #fdced4;
    position:absolute;
  }
  .bt1,.bt2,.bt3,.bt
  {
    margin-left:20px;
    border-radius:24px;
     background-color: #fdced4;
     font-size: 20px;
     margin-top: 15px;

  }
  .bt1:hover, .btdrop1:hover, .bt1:hover, .btdrop1:hover, .bt1:hover, .btdrop1:hover,.bt:hover,.btdrop:hover
  {
    background-color:white;
  }
 .btdrop1, .btdrop2, .btdrop3
  {
    margin-left:60px;
    border-radius:24px;
     background-color: #fdced4;
     font-size: 20px;
    display:none;
    margin-top: 15px;
   width: 150px;
   font-size: 15px;
   
  }
 a{
  color: black;
 }
img
{
  margin-top: 15px;
}

.itemp{
  width:250px;
  text-align:center;
  display:block;
  background-color: transparent;
  border: 1px solid transparent;
  margin-right: 10px;
  margin-bottom: 1px;
  float: left;
}

#index-gallery{
  width:465px;
  top: 210px;
  left: 300px;
}

</style>
<script>
$(document).ready(function(){
  $(".bt1").click(function(){
    $(".btdrop1").slideToggle("slow");

  });
});
$(document).ready(function(){
  $(".bt2").click(function(){
    $(".btdrop2").slideToggle("slow");

  });
});
$(document).ready(function(){
  $(".bt3").click(function(){
    $(".btdrop3").slideToggle("slow");

  });
});
  </script>
<div id="sidemenu">
<img src="guide.png" style="height:25px;margin:7px"> <button class="bt1">Guidelines </button>
  <button class="btdrop1"><a href="">Redress of Public Grievance </a></button>
    <button class="btdrop1"><a href="">Other Guidelines</a></button>

<img src="redressal.png" style="height:40px;"> <button class="bt2">Redressal</button><br>
   <button class="btdrop2"><a href="">Mechanism</a></button>
    <button class="btdrop2"><a href="">Process Flow</a></button>
<img src="employee.jpg" style="height:30px;margin:7px"><button class="bt3"> Nodal Officer</button>
   <button class="btdrop3"><a href="">Central Government</a></button>
    <button class="btdrop3"><a href="">State Government</a></button>
<img src="contact.png" style="height:25px;margin:7px"><button class="bt">Contact Us</button><br>
<img src="about.png" style="height:25px;margin:7px"><button class="bt">About Us</button><br>

 </div>
 
 <!--<div class="main">
  <img src="employee.jpg" alt="employee" height="250px" width="300px" />
  <span style="display: block;">PUBLIC</span>
 </div>
 <div class="main">
   <img src="guide.png" alt="guide" height="250px" width="300px" style="margin-left: 300px" />
   <span style="display: block;float: right;">kjhgfdxsdfghjk</span>
 </div>-->
 

<div class="main">
 <div id="index-gallery">
  <div class="itemp">
    <img src="employee.jpg" height="250px" width="250px" alt="Employee"/>
    <p>OFFICER LOGIN</p>
  </div>
</div>
  <div id="index-gallery">
  <div class="itemp" style="margin-left:30px;">
    <img src="employee.jpg" height="250px" width="250px" alt="Guide"/>
    <p>PUBLIC LOGIN</p>
  </div>
</div>
</div>

 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>  
</aside>