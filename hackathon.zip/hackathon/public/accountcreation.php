<?php
include('includes/config.php');
session_start();
error_reporting(0);
if(isset($_POST['submit']))
{
	$username=$_POST['username'];
	$password=md5($_POST['password']);
	$id=$_SESSION["id"];
	$query=mysqli_query($con,"update `register` set `username`= '$username' , `password`='$password' where `id`='$id' ");
	$msg="Registration successfull. Now You can login !";
	$extra="login.php";
//$extra="dashboard.php";//
//$_SESSION['otp1']=$_POST['otp1'];
$_SESSION['login']=$_POST['username'];
$_SESSION['id']=$num['id'];
$host=$_SERVER['HTTP_HOST'];
$uip=$_SERVER['REMOTE_ADDR'];
$status=1;
//$log=mysqli_query($con,"insert into userlog(uid,username,userip,status) values('".$_SESSION['id']."','".$_SESSION['login']."','$uip','$status')");
$uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
header("location:http://$host$uri/$extra");
exit();
}
?>
<!--insert into register(name,gender,address,country,state,district,pincode,contactNo,landline,email,exservice) values('$fullname','$gender','$address','$country','$state','$district','$contactno','$landline','$email','exservice')"-->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>CMS | User Registration</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">
    
    	<script>
function userAvailability() {
//$("#loaderIcon").show();
jQuery.ajax({
url: "authorize_register.php",
data:'username='+$("#username").val(),
type: "POST",
success:function(data){
$("#regno-availability-status1").html(data);

},
error:function (){}
});

}
function valid() {

var pass=document.getElementById("password").value;
var cpass=document.getElementById("confrimpassowrd").value;

if (pass!=cpass)
{
  
  jQuery.ajax({
	url:"try.php",
	type: "POST",
    success:function(data){
       $("#password1").html(data); 
       document.getElementById("submit").setAttribute("disabled", "disabled"); 
   },
   error:function (){

   }
    });
}
else
{
	$("#password1").html(" ");
	$('#submit').removeAttr('disabled');
}

}

</script>
  </head>

  <body>
	  <div style="background: white;"  id="login-page">
	  	<div class="container">
	  		<img style="height:55px; margin-left: -5vw; width:100px;" src="ssnlogo.png" align="left">
	<h3 align="center" style="color:darkblue;font-weight: bold;">Grievance Redressal System</h3>
	<hr />
		      <form class="form-login" method="post">
		        <h2 style="background: darkblue;" class="form-login-heading">User Registration</h2>
		        <p style="padding-left: 1%; color: green">
		        	<?php if($msg){
header("location:index.php");

		        		}?>


		        </p>
		        <div class="login-wrap">
		         <!--<input type="text" class="form-control" placeholder="Full Name" name="fullname" required="required" autofocus>
		         <img src="LoaderIcon.gif" id="loaderIcon" style="display:none" />
		            <br>
		         <input type="text" class="form-control" placeholder="" name="regno" id="regno" required="required" onBlur="regnoAvailability()">
		         <span id="regno-availability-status1" style="font-size:12px;"></span>
		            <br>   
		            <input type="email" class="form-control" placeholder="Email ID" id="email" name="email" required="required" readonly>
		             <span id="user-availability-status1" style="font-size:12px;"></span>
		            <br>
		            <input type="password" class="form-control" placeholder="Password" required="required" name="password"><br >
		             <input type="text" class="form-control" maxlength="10" name="contactno" id="cn" placeholder="Contact no" required="required" onBlur="con()" autofocus>
		              <span id="contact" style="font-size:12px;"></span>
		            <br>-->
		            <input type="text" class="form-control" placeholder="Full Name" id="username" name="username" required="required" autofocus onblur="userAvailability()">
		            <span id="regno-availability-status1" style="font-size:12px;"></span>
		            <br>   
		            <input type="text" class="form-control" placeholder="Password" name="password" id="password"required="required" autofocus><br>
		            <input type="text" class="form-control" placeholder="Confirm Password" name="confrimpassowrd" required="required" id="confrimpassowrd" autofocus onblur="valid()">
		            <span id="password1" style="font-size:12px;"></span>
		            <br><br>
		           <button class="btn btn-theme btn-block" style="background: darkblue;"  type="submit" name="submit" id="submit" disabled="disabled" ><i class="fa fa-user"></i> Register</button>
		           
		            
		            <div class="registration">
		                Already Registered<br/>
		                <a class="" href="index.php">
		                   Sign in
		                </a>
		            </div>
		
		        </div>
		
		      
		
		      </form>	  	
	  	
	  	</div>
	  </div>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <!--BACKSTRETCH-->
    <!-- You can use an image of whatever size. This script will stretch to fit in any screen size.-->
    <script type="text/javascript" src="assets/js/jquery.backstretch.min.js"></script>
    <script>
        $.backstretch("assets/img/login-bg.jpg", {speed: 500});
    </script>


  </body>
</html>
