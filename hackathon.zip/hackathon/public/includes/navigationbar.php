<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<style>

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #fdced4;
  margin-top: -50px;
}

li {
  float: left;
}

li a, .dropbtn {
  display: inline-block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
  background-color: #fdced4;
}

li.dropdown {
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {background-color: #f1f1f1;}

.dropdown:hover .dropdown-content {
  display: block;
}
button
{
  margin-top:5px;
  background-color:#fdced4;
  margin-bottom: 5px;
}
</style>
</head>
<body>
<div style="margin-top: 10px;height: 50px;background-color:#fdced4;">
  <img src="guide.png" style="height:25px;margin:7px">  
<div class="btn-group" style="margin-top: 5px;">
<button class="dropdown dropdown-toggle" data-toggle="dropdown">
    Guidelines 
</button>
  <div class="dropdown-menu">
    <a class="dropdown-item" href="#">Redress of Public Grievance </a>
    <a class="dropdown-item" href="#">Other Guidelines</a>  </div>
</div>
<img src="redressal.png" style="height:40px;;margin:7px;">
<div class="btn-group">
<button class="dropdown dropdown-toggle" data-toggle="dropdown">
    Redressal
</button>
  <div class="dropdown-menu">
    <a class="dropdown-item" href="#">Mechanism</a>
    <a class="dropdown-item" href="#">Process Flow</a>  </div>
</div>
<img src="employee.jpg" style="height:30px;margin:7px"><div class="btn-group">
<button class="dropdown dropdown-toggle" data-toggle="dropdown">
    Nodal Officer
</button>
  <div class="dropdown-menu">
    <a class="dropdown-item" href="#">Central Government</a>
    <a class="dropdown-item" href="#">State Government</a>  </div>
</div>
<img src="contact.png" style="height:25px;margin:7px"><div class="btn-group">
<button class="dropdown dropdown-toggle" data-toggle="dropdown">
   Contact Us
</button></div>
<img src="about.png" style="height:25px;margin:7px"><div class="btn-group">
<button class="dropdown dropdown-toggle" data-toggle="dropdown">
   About Us
</button></div>
</div>

<!-- <ul style="margin-top: 10px;">
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn" style="font-weight: bold"><img src="guide.png" style="width: 20px; height: 20px;">  GUIDELINES</a>
    <div class="dropdown-content">
      <a href="#">Redress of public grievance</a>
      <a href="#">Other guidelines</a>
     </div>
  </li>
  
    <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn" style="font-weight: bold"><img src="redressal.png" style="width: 20px; height: 20px;"> REDRESSAL</a>
    <div class="dropdown-content">
      <a href="#">Mechanism</a>
      <a href="#">Process flow</a>
      </div>
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn" style="font-weight: bold"><img src="nodal.jpg" style="width: 20px; height: 20px;"> NODAL OFFICERS</a>
    <div class="dropdown-content">
      <a href="#">Central government</a>
      <a href="#">State government</a>
      </div>
  </li>
  <li >
    <a href="javascript:void(0)" class="dropbtn" style="font-weight: bold"><img src="contact.png" style="width: 20px; height: 20px;"> CONTACT US</a>
     </li>
  <li >
    <a href="javascript:void(0)" class="dropbtn" style="font-weight: bold"><img src="about.png" style="width: 20px; height: 20px;"> ABOUT US</a>
    </li>

</ul>-->
</body>
</html>
