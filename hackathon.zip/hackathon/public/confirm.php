<?php include('includes/header.php');?>
<?php include('includes/sidebar.php');?>
<?php
include('includes/config.php');
session_start();
error_reporting(0);
if(isset($_POST['submit']))
{
	$username=$_POST['username'];
	$password=md5($_POST['password']);
	$id=$_SESSION["id"];
	$query=mysqli_query($con,"update `register` set `username`= '$username' , `password`='$password' where `id`='$id' ");
	$msg="Registration successfull. Now You can login !";
	$extra="login.php";
//$extra="dashboard.php";//
//$_SESSION['otp1']=$_POST['otp1'];
$_SESSION['login']=$_POST['username'];
$_SESSION['id']=$num['id'];
$host=$_SERVER['HTTP_HOST'];
$uip=$_SERVER['REMOTE_ADDR'];
$status=1;
//$log=mysqli_query($con,"insert into userlog(uid,username,userip,status) values('".$_SESSION['id']."','".$_SESSION['login']."','$uip','$status')");
$uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
header("location:http://$host$uri/$extra");
exit();
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<style>
{
	margin: 0;
	padding:0;
	//font-family: Times New Roman;
	background:white;
}
.box
{
	width: 300px;
	margin-top:20px;
	height:450px;
	padding: 30px;
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-50%,-50%); ;
	//background-image: linear-gradient(#ebe6e0, white);
	text-align: center;
	background-color: #ebe6e0;
	
}
.box h2
{
	color: black;
	text-transform: uppercase;
	font-weight: 100;

}
.box input[type = "text"],.box input[type="password"]
{
	border: 0;
	//background:white;
	display: block;
	margin:20px auto;
	text-align: center;
	border:2px solid white;
	padding:14px 10px;
	width: 200px;
	outline: none;
	color: black;
	border-radius:12px ;
font-size:20px;
	//font-family:Times New Roman;

}
::placeholder {
  color:black;
  opacity: 1; /* Firefox */
  font-size:15px;
}

.box input[type = "text"],.box input[type="password"]
{
 width: 200px;
 height: 30px;

}
.box input[type = "submit"]
{
	border: 0;
	//background:white;
	display: block;
	//margin: 20px auto;
	text-align: center;
	border:2px solid white;
	//padding:14px 40px;
	//font-family: Times New Roman;
	outline: none;
	color: black;
	border-radius:12px ;
	margin-left: 150px;
	cursor: pointer;
	font-size:15px;
	width: 100px;
    height: 30px;

}
.box input[type = "submit"]:hover
{
	background:white;
}

</style>
<script>
function userAvailability() {
//$("#loaderIcon").show();
jQuery.ajax({
url: "authorize_register.php",
data:'username='+$("#username").val(),
type: "POST",
success:function(data){
$("#regno-availability-status1").html(data);

},
error:function (){}
});

}
function valid() {

var pass=document.getElementById("password").value;
var cpass=document.getElementById("confrimpassowrd").value;

if (pass!=cpass)
{
  
  jQuery.ajax({
	url:"try.php",
	type: "POST",
    success:function(data){
       $("#password1").html(data); 
       document.getElementById("submit").setAttribute("disabled", "disabled"); 
   },
   error:function (){

   }
    });
}
else
{
	$("#password1").html(" ");
	$('#submit').removeAttr('disabled');
}

}

</script>
</head>
<body>
<form class="box" action="" method="post" >
	<h3>ACCOUNT CREATION</h3><br>
	<input type="text" class="form-control" placeholder="Full Name" id="username" name="username" required="required" autofocus onblur="userAvailability()">
		            <span id="regno-availability-status1" style="font-size:12px;"></span>
		  
		            <input type="text" class="form-control" placeholder="Password" name="password" id="password"required="required" autofocus>
		            <input type="text" class="form-control" placeholder="Confirm Password" name="confrimpassowrd" required="required" id="confrimpassowrd" autofocus onblur="valid()">
		            <span id="password1" style="font-size:12px;"></span><br>
		      
		           <button class="btn btn-theme btn-block" style="background: #af9b83;"  type="submit" name="submit" id="submit" disabled="disabled" ><i class="fa fa-user"></i> Register</button>
		           
</form>
<?php include('includes/footer.php');?>
</body>
</html>